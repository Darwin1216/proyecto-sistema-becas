/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.consultas;
import modelo.ficha;
import modelo.fichaDao;
import modelo.solicitudDAO;
import modelo.validacionbecaDAO;
import modelo.reportesDAO;
import modelo.Reportes;
import modelo.validacionbecas;

@WebServlet(name = "estudiantesServlet", urlPatterns = {"/estudiantesServlet"})
public class estudiantesServlet extends HttpServlet {

    String vistaEstudiantes = "/estudiantil.jsp";
    String vistaficha = "/ficha.jsp";
    String vistadocumentacion = "/documentacion.jsp";
    String vistabecas = "/becas.jsp";
    String vistasolicitud = "/consultas.jsp";
    String vistavalidacion = "/validaciones.jsp";
    String vistareporte = "/reportes.jsp";

    String listaEstudiantes = "estudiantil.jsp";
    String listadocumentacion = "documentacion.jsp";
    String listabecas = "becas.jsp";
    String listasolicitudes = "consultas.jsp";

    fichaDao fichdao;
    solicitudDAO solidao;
    validacionbecaDAO valdao;
    reportesDAO reportdao;
    String mensaje;

    // metodo para dar orden de abrir la conexion
    public void init() throws ServletException {
        // datos xml
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUSERName = getServletContext().getInitParameter("jdbcUSERName");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
        try {
            fichdao = new fichaDao(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            solidao = new solicitudDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            valdao = new validacionbecaDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            reportdao = new reportesDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
        } catch (SQLException ex) {
            Logger.getLogger(estudiantesServlet.class.getName()).log(Level.SEVERE, null, ex);
            mensaje = "Error de Conexion";
        }
        mensaje = "Listos para iniciar conexión";
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        String accion = request.getParameter("accion");
        RequestDispatcher dispatcher = request.getRequestDispatcher(listaEstudiantes);
        if (accion.equalsIgnoreCase("ficha")) {
            request.getRequestDispatcher(vistaficha).forward(request, response);
        }
        if (accion.equalsIgnoreCase("listar-ficha")) {
            System.out.println("Estamos listando desde estudiantesServlet - Ficha");
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("listaficha", listaficha);
            dispatcher = request.getRequestDispatcher(listaEstudiantes);
            dispatcher.forward(request, response);
        }
        if (accion.equalsIgnoreCase("listar-documentacion")) {
            System.out.println("Estamos listando desde estudiantesServlet - Documentacion");
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("listaficha", listaficha);
            dispatcher = request.getRequestDispatcher(listadocumentacion);
            dispatcher.forward(request, response);
        }
        if (accion.equalsIgnoreCase("listar-becas")) {
            System.out.println("Estamos listando desde estudiantesServlet - Becas");
            List<validacionbecas> listavali = valdao.listarvali();
            List<consultas> listasolicitud = solidao.listarlistasolicitud();
            request.setAttribute("listaconsulta", listasolicitud);
            request.setAttribute("listavalidaciones", listavali);
            dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
        }
        if (accion.equalsIgnoreCase("listar-consultas")) {
            System.out.println("Estamos listando desde estudiantesServlet - Consultas");
            List<consultas> listasolicitud = solidao.listarlistasolicitud();
            request.setAttribute("listaconsulta", listasolicitud);
            dispatcher = request.getRequestDispatcher(listasolicitudes);
            dispatcher.forward(request, response);
        }
        
        
        
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);

        String accion = request.getParameter("accion");
        RequestDispatcher dispatcher = request.getRequestDispatcher(vistaEstudiantes);
        if (accion.equalsIgnoreCase("create")) {
            String idFicha = request.getParameter("id");
            if (idFicha == null || idFicha.isEmpty()) {
                System.out.println("Insertar");
                ficha newficha = new ficha();
                String tipdoc = request.getParameter("tipdoc");
                String cedu = request.getParameter("cedu");
                String priape = request.getParameter("priape");
                String segape = request.getParameter("segape");
                String prinom = request.getParameter("prinom");
                String segnom = request.getParameter("segnom");
                String sexo = request.getParameter("sexo");
                String genero = request.getParameter("genero");
                String estadoc = request.getParameter("estadoc");
                String etnia = request.getParameter("etnia");
                String PuebloN = request.getParameter("PuebloN");
                String tsangre = request.getParameter("tsangre");
                String tdiscacidad = request.getParameter("tdiscacidad");
                String porcdiscacidad = request.getParameter("porcdiscacidad");
                String nroc = request.getParameter("nroc");
                String tdisc = request.getParameter("tdisc");
                String fnaci = request.getParameter("fnaci");
                String paisnac = request.getParameter("paisnac");
                String cannac = request.getParameter("cannac");
                String parecid = request.getParameter("parecid");
                String provres = request.getParameter("provres");
                String canresi = request.getParameter("canresi");
                String tcolegio = request.getParameter("tcolegio");
                String mocarrera = request.getParameter("mocarrera");
                String jcarrera = request.getParameter("jcarrera");
                String finicio = request.getParameter("finicio");
                String fmatricula = request.getParameter("fmatricula");
                String tmatricula = request.getParameter("tmatricula");
                String nacademico = request.getParameter("nacademico");
                String semanaperiodo = request.getParameter("semanaperiodo");
                String apmateria = request.getParameter("apmateria");
                String paralelo = request.getParameter("paralelo");
                String apgratuidad = request.getParameter("apgratuidad");
                String rpdiferecial = request.getParameter("rpdiferecial");
                String esdedica = request.getParameter("esdedica");
                String semplea = request.getParameter("semplea");
                String rbono = request.getParameter("rbono");
                String realizapracticas = request.getParameter("realizapracticas");
                String horasprac = request.getParameter("horasprac");
                String institucionpracticas = request.getParameter("institucionpracticas");
                String secpract = request.getParameter("secpract");
                String tipobeca = request.getParameter("tipobeca");
                String primer = request.getParameter("primer");
                String segunda = request.getParameter("segunda");
                String tercera = request.getParameter("tercera");
                String cuarta = request.getParameter("cuarta");
                String quinta = request.getParameter("quinta");
                String sexta = request.getParameter("sexta");
                Double montobeca = Double.parseDouble(request.getParameter("montobeca"));
                String porcentage = request.getParameter("porcentage");
                String porcentagedebeca = request.getParameter("porcentagedebeca");
                String tfinabeca = request.getParameter("tfinabeca");
                Double valorbeca = Double.parseDouble(request.getParameter("valorbeca"));
                String vinculacion = request.getParameter("vinculacion");
                String proyectovin = request.getParameter("proyectovin");
                String celectronico = request.getParameter("celectronico");
                String celular = request.getParameter("celular");
                String nfpadre = request.getParameter("nfpadre");
                String frmadre = request.getParameter("frmadre");
                Double ingrohogar = Double.parseDouble(request.getParameter("ingrohogar"));
                String mhohar = request.getParameter("mhohar");

                newficha = new ficha(tipdoc, cedu, priape, segape, prinom, segnom, sexo, genero, estadoc, etnia, PuebloN, tsangre, tdiscacidad, porcdiscacidad, nroc, tdisc, fnaci, paisnac, cannac, parecid, provres, canresi, tcolegio, mocarrera, jcarrera, finicio, fmatricula, tmatricula, nacademico, semanaperiodo, apmateria, paralelo, apgratuidad, rpdiferecial, esdedica, semplea, rbono, realizapracticas, horasprac, institucionpracticas, secpract, tipobeca, primer, segunda, tercera, cuarta, quinta, sexta, montobeca, porcentage, porcentagedebeca, tfinabeca, valorbeca, vinculacion, proyectovin, celectronico, celular, nfpadre, frmadre, ingrohogar, mhohar);
                try {
                    fichdao.insertarficha(newficha);
                    mensaje = "Los datos se insertaron correctamente";
                } catch (Exception e) {
                    System.out.println("Error: " + e);
                    mensaje = "Ocurrio un error al insertar los datos";
                }
            }
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaficha", listaficha);
            dispatcher = request.getRequestDispatcher(vistaEstudiantes);
            dispatcher.forward(request, response);
        }

        if (accion.equalsIgnoreCase("create-beca")) {
            insertarBeca(request, response);
        }
        
        if (accion.equalsIgnoreCase("create-validacion")) {
            insertarValidacion(request, response);
        }
        
    }

    private void insertarBeca(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //PARAMETROS DEL FORMULARIO
        String tipo = request.getParameter("tipo");
        String certificadoest = request.getParameter("certificadoest");
        String copiacedula = request.getParameter("copiacedula");
        String certifies = request.getParameter("certifies");
        String otrosdocumentos = request.getParameter("otrosdocumentos");
        String idConsulta = request.getParameter("id");
        if (idConsulta == null || idConsulta.isEmpty()) {
            int ficha = Integer.parseInt(request.getParameter("idfich"));
            System.out.println("Insertar-beca");
            // Crea un nuevo objeto de consultas con los datos del formulario
            consultas newconsulta = new consultas(tipo, certificadoest, copiacedula, certifies, otrosdocumentos, ficha);
            try {
                // Intenta insertar la nueva consulta en la base de datos
                solidao.insertarsolicitud(newconsulta);
                mensaje = "Los datos se insertaron correctamente";
            } catch (Exception e) {
                System.out.println("Error: " + e);
                mensaje = "Ocurrió un error al insertar los datos";
            }
        }
        List<consultas> listaconsulta = solidao.listarlistasolicitud();
        request.setAttribute("mensaje", mensaje);
        request.setAttribute("listaconsulta", listaconsulta);

        RequestDispatcher dispatcher = request.getRequestDispatcher(listasolicitudes);
        dispatcher.forward(request, response);
    }

    private void insertarValidacion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String estado = request.getParameter("estad");
        String observacion = request.getParameter("obser");
        String idValidacion = request.getParameter("ids");
        if (idValidacion == null || idValidacion.isEmpty()) {
            int soli = Integer.parseInt(request.getParameter("idsolicitud"));
            System.out.println("Insertar-validacion");
            validacionbecas newvalidacion = new validacionbecas(estado, observacion, soli);
            try {
                valdao.insertarvalidacion(newvalidacion);
                mensaje = "Los datos se insertaron correctamente";
            } catch (Exception e) {
                System.out.println("Error: " + e);
                mensaje = "Ocurrió un error al insertar los datos";
            }
        }

        List<validacionbecas> listavali = valdao.listarvali();
        List<consultas> listasolicitud = solidao.listarlistasolicitud();
        request.setAttribute("listaconsulta", listasolicitud);

        request.setAttribute("listavalidaciones", listavali);
        request.setAttribute("mensaje", mensaje);

        RequestDispatcher dispatcher = request.getRequestDispatcher(listabecas);
        dispatcher.forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
