/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Reportes;
import modelo.consultas;
import modelo.ficha;
import modelo.fichaDao;
import modelo.reportesDAO;
import modelo.solicitudDAO;
import modelo.validacionbecaDAO;
import modelo.validacionbecas;

/**
 *
 * @author Usuario DELL
 */
public class accionServlet extends HttpServlet {

    String vistaEstudiantes = "/estudiantil.jsp";
    String vistaficha = "/ficha.jsp";
    String vistadocumentacion = "/documentacion.jsp";
    String vistabecas = "/becas.jsp";
    String vistasolicitud = "/consultas.jsp";
    String vistaeditconsul = "/editarconsulta.jsp";
    String vistaeditficha = "/editarficha.jsp";
    String vistaeditval = "/editarvalidacion.jsp";
    String vistareporte = "/reportes.jsp";

    String listaEstudiantes = "estudiantil.jsp";
    String listadocumentacion = "documentacion.jsp";
    String listabecas = "becas.jsp";
    String listasolicitudes = "consultas.jsp";

    fichaDao fichdao;
    solicitudDAO solidao;
    validacionbecaDAO valdao;
    reportesDAO reportdao;
    String mensaje;

    // metodo para dar orden de abrir la conexion
    public void init() throws ServletException {
        // datos xml
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUSERName = getServletContext().getInitParameter("jdbcUSERName");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
        try {
            fichdao = new fichaDao(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            solidao = new solicitudDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            valdao = new validacionbecaDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
            reportdao = new reportesDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
        } catch (SQLException ex) {
            Logger.getLogger(estudiantesServlet.class.getName()).log(Level.SEVERE, null, ex);
            mensaje = "Error de Conexion";
        }
        mensaje = "Listos para iniciar conexión";
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        
        //---------------------------------------------------------------------------------------------------//
        //================= METODO PARA EDITAR Y ELIMINAR UN REGISTRO EN FICHAESTUDIANTE ====================//
        //---------------------------------------------------------------------------------------------------//
        if (accion.equalsIgnoreCase("editar-fi")) {
                String idficha = request.getParameter("idfi");
                if (idficha != null && !idficha.isEmpty()) {
                    try {
                        int fiid = Integer.parseInt(idficha);
                        ficha edifich = fichdao.buscarfich(fiid);
                        request.setAttribute("editarficha", edifich);
                        request.setAttribute("mensaje", mensaje);
                        RequestDispatcher dispatcher = request.getRequestDispatcher(vistaeditficha);
                        dispatcher.forward(request, response);
                    } catch (Exception e) {
                        System.out.println("Error al editar el dato" + e);
                        mensaje = "Error al editar el dato";
                    }
                }
            } else if (accion.equalsIgnoreCase("eliminar-ficha")) {
            String IdElimi = request.getParameter("elimin");
            int idEliminar = Integer.parseInt(IdElimi);
            try {
                fichdao.Eliminarficha(idEliminar);
                mensaje = "Los datos se eliminaron correctamente";
            } catch (Exception e) {
                System.out.println("Error al eliminar los datos: " + e);
                mensaje = "Error al eliminar los datos";
            }
            
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaficha", listaficha);
            RequestDispatcher dispatcher = request.getRequestDispatcher(listaEstudiantes);
            dispatcher.forward(request, response);
        }
    //-----------------------------------------------------------------------------------------------//    
    
        
        if (accion.equalsIgnoreCase("eliminar-ficha2")) {
            String IdElimin = request.getParameter("elimin2");
            int idElimina = Integer.parseInt(IdElimin);
            try {
                fichdao.Eliminarficha(idElimina);
                mensaje = "Los datos se eliminaron correctamente";
            } catch (Exception e) {
                System.out.println("Error al eliminar los datos: " + e);
                mensaje = "Error al eliminar los datos";
            }
            
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaficha", listaficha);
            RequestDispatcher dispatcher = request.getRequestDispatcher(listadocumentacion);
            dispatcher.forward(request, response);
        }
        
        
        
        //---------------------------------------------------------------------------------------------------//
        //=================== METODO PARA EDITAR Y ELIMINAR UN REGISTRO EN SOLICITUDES ======================//
        //---------------------------------------------------------------------------------------------------//
            if (accion.equalsIgnoreCase("editar-id")) {
                String idsolicitudes = request.getParameter("idsoli");
                if (idsolicitudes != null && !idsolicitudes.isEmpty()) {
                    try {
                        int idsol = Integer.parseInt(idsolicitudes);
                        consultas editarsoli = solidao.buscarsoli(idsol);
                        request.setAttribute("editarsoli", editarsoli);
                        request.setAttribute("mensaje", mensaje);
                        RequestDispatcher dispatcher = request.getRequestDispatcher(vistaeditconsul);
                        dispatcher.forward(request, response);
                    } catch (Exception e) {
                        System.out.println("Error al editar el dato" + e);
                        mensaje = "Error al editar el dato";
                    }
                }
            } else if (accion.equalsIgnoreCase("eliminar-soli")) {
                String IdEliminar = request.getParameter("elim");
                int idEliminar = Integer.parseInt(IdEliminar);
                try {
                    solidao.Eliminarsoli(idEliminar);
                    mensaje = "Los datos se eliminaron correctamente";
                } catch (Exception e) {
                    System.out.println("Error al eliminar los datos: " + e);
                    mensaje = "Error al eliminar los datos";
                }
                List<consultas> listasolicitud = solidao.listarlistasolicitud();

                request.setAttribute("mensaje", mensaje);
                request.setAttribute("listaconsulta", listasolicitud);
                RequestDispatcher dispatcher = request.getRequestDispatcher(listasolicitudes);
                dispatcher.forward(request, response);
            }
        //----------------------------------------------------------------------------------------------------//
            
        
        if (accion.equalsIgnoreCase("eliminar-soli2")) {
            String IdEliminar = request.getParameter("elim");
            int idEliminar = Integer.parseInt(IdEliminar);
            try {
                solidao.Eliminarsoli(idEliminar);
                mensaje = "Los datos se eliminaron correctamente";
            } catch (Exception e) {
                System.out.println("Error al eliminar los datos: " + e);
                mensaje = "Error al eliminar los datos";
            }
            List<validacionbecas> listavali = valdao.listarvali();
            List<consultas> listasolicitud = solidao.listarlistasolicitud();
            
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaconsulta", listasolicitud);
            request.setAttribute("listavalidaciones", listavali);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
        }
        
        
        
        //---------------------------------------------------------------------------------------------------//
        //=================== METODO PARA EDITAR Y ELIMINAR UN REGISTRO EN VALIDACIONES ======================//
        //---------------------------------------------------------------------------------------------------//
        
        if (accion.equalsIgnoreCase("editar-val")) {
                String idvalidaciones = request.getParameter("idval");
                if (idvalidaciones != null && !idvalidaciones.isEmpty()) {
                    try {
                        int idvali = Integer.parseInt(idvalidaciones);
                        validacionbecas editarvali = valdao.buscarvalidar(idvali);
                        request.setAttribute("editarvali", editarvali);
                        request.setAttribute("mensaje", mensaje);
                        RequestDispatcher dispatcher = request.getRequestDispatcher(vistaeditval);
                        dispatcher.forward(request, response);
                    } catch (Exception e) {
                        System.out.println("Error al editar el dato" + e);
                        mensaje = "Error al editar el dato";
                    }
                }
            } else if (accion.equalsIgnoreCase("eliminar-validacion")) {
            String IdElimin = request.getParameter("eli");
            int idEli = Integer.parseInt(IdElimin);
            try {
                valdao.Eliminarvalidacion(idEli);
                mensaje = "Los datos se eliminaron correctamente";
            } catch (Exception e) {
                System.out.println("Error al eliminar los datos: " + e);
                mensaje = "Error al eliminar los datos";
            }
            List<validacionbecas> listavali = valdao.listarvali();
            List<consultas> listasolicitud = solidao.listarlistasolicitud();
            
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaconsulta", listasolicitud);
            request.setAttribute("listavalidaciones", listavali);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String accion = request.getParameter("accion");
        if (accion.equalsIgnoreCase("listar-reportes")) {
            System.out.println("Estamos listando desde estudiantesServlet - REPORTES");
            List<Reportes> listareporte = reportdao.listarreport();
            request.setAttribute("reporte", listareporte);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistareporte);
            dispatcher.forward(request, response);
        }
        
        if (accion.equalsIgnoreCase("buscarestudiante")) {
            String fiid = request.getParameter("buscar");
            int idBuscar =Integer.parseInt(fiid);
            List<ficha> buscarficha = fichdao.buscarestudiante(idBuscar);
            request.setAttribute("listaficha", buscarficha);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistaEstudiantes);
            dispatcher.forward(request, response);
        }
        if (accion.equalsIgnoreCase("buscarestudiante2")) {
            String fiid = request.getParameter("buscar2");
            int idBuscar =Integer.parseInt(fiid);
            List<ficha> buscarficha = fichdao.buscarestudiante(idBuscar);
            request.setAttribute("listaficha", buscarficha);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistadocumentacion);
            dispatcher.forward(request, response);
        }
        if (accion.equalsIgnoreCase("buscarsolicitud")) {
            String idb = request.getParameter("busqueda");
            int idBusqueda =Integer.parseInt(idb);
            List<consultas> listabusqsoli = solidao.buscar(idBusqueda);
            request.setAttribute("listaconsulta", listabusqsoli);
            RequestDispatcher dispatcher = request.getRequestDispatcher(listasolicitudes);
            dispatcher.forward(request, response);
        }        
        if (accion.equalsIgnoreCase("buscarvalidacion")) {
            String valid = request.getParameter("busq");
            int idBusq =Integer.parseInt(valid);
            List<consultas> listabusqsoli = solidao.buscar(idBusq);
            List<validacionbecas> listavali = valdao.listarvali();
            request.setAttribute("listavalidaciones", listavali);
            request.setAttribute("listaconsulta", listabusqsoli);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
        }
        
        if (accion.equalsIgnoreCase("buscarvalidacion2")) {
            String valid = request.getParameter("buq");
            int idBuq =Integer.parseInt(valid);
            List<validacionbecas> listavalidacionbusq = valdao.buscarvalidacion(idBuq);
            List<consultas> listasolicitud = solidao.listarlistasolicitud();
            request.setAttribute("listavalidaciones", listavalidacionbusq);
            request.setAttribute("listaconsulta", listasolicitud);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
        }
        
        if (accion.equalsIgnoreCase("buscarreporte")) {
            String repo = request.getParameter("busq");
            int idsBuqr =Integer.parseInt(repo);
            List<Reportes> listabusqreportes = reportdao.buscar(idsBuqr);
            request.setAttribute("reporte", listabusqreportes);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistareporte);
            dispatcher.forward(request, response);
        }
    }

    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String accion = request.getParameter("accion");
        if (accion.equalsIgnoreCase("editar-fichaestudiante")) {
            editarfichas(request, response);
        }
        
        if (accion.equalsIgnoreCase("editar-beca")) {
            editarbeca(request, response);
        }
        
        if (accion.equalsIgnoreCase("editar-validacion")) {
            editarvalidacion(request, response);
        }

    }

    private void editarbeca(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //PARAMETROS DEL FORMULARIO
        String nomb = request.getParameter("nombre");
        String ape = request.getParameter("apellido");
        String ced = request.getParameter("cedula");
        String tipo = request.getParameter("tipo");
        String certificadoest = request.getParameter("certificadoest");
        String copiacedula = request.getParameter("copiacedula");
        String certifies = request.getParameter("certifies");
        String otrosdocumentos = request.getParameter("otrosdocumentos");
        String idConsulta = request.getParameter("id");
        
            System.out.println("Editar");
            int idsolic = Integer.parseInt(idConsulta);
            consultas newconsultas = new consultas(idsolic, tipo, certificadoest, copiacedula, certifies,otrosdocumentos,nomb,ape,ced);
            
            try {
                solidao.editarsolicitud(newconsultas);
                mensaje = "Los datos se actualizaron correctamente";
            } catch (Exception e) {
                System.out.println("Error: " + e);
                mensaje = "Ocurrió un error al actualizar los datos";
            }
            List<consultas> listaconsulta = solidao.listarlistasolicitud();
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaconsulta", listaconsulta);

            RequestDispatcher dispatcher = request.getRequestDispatcher(vistasolicitud);
            dispatcher.forward(request, response);
    }

    
    private void editarfichas(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //PARAMETROS DEL FORMULARIO
        String tipdoc = request.getParameter("tipdoc");
        String cedu = request.getParameter("cedu");
        String priape = request.getParameter("priape");
        String segape = request.getParameter("segape");
        String prinom = request.getParameter("prinom");
        String segnom = request.getParameter("segnom");
        String sexo = request.getParameter("sexo");
        String genero = request.getParameter("genero");
        String estadoc = request.getParameter("estadoc");
        String etnia = request.getParameter("etnia");
        String PuebloN = request.getParameter("PuebloN");
        String tsangre = request.getParameter("tsangre");
        String tdiscacidad = request.getParameter("tdiscacidad");
        String porcdiscacidad = request.getParameter("porcdiscacidad");
        String nroc = request.getParameter("nroc");
        String tdisc = request.getParameter("tdisc");
        String fnaci = request.getParameter("fnaci");
        String paisnac = request.getParameter("paisnac");
        String cannac = request.getParameter("cannac");
        String parecid = request.getParameter("parecid");
        String provres = request.getParameter("provres");
        String canresi = request.getParameter("canresi");
        String tcolegio = request.getParameter("tcolegio");
        String mocarrera = request.getParameter("mocarrera");
        String jcarrera = request.getParameter("jcarrera");
        String finicio = request.getParameter("finicio");
        String fmatricula = request.getParameter("fmatricula");
        String tmatricula = request.getParameter("tmatricula");
        String nacademico = request.getParameter("nacademico");
        String semanaperiodo = request.getParameter("semanaperiodo");
        String apmateria = request.getParameter("apmateria");
        String paralelo = request.getParameter("paralelo");
        String apgratuidad = request.getParameter("apgratuidad");
        String rpdiferecial = request.getParameter("rpdiferecial");
        String esdedica = request.getParameter("esdedica");
        String semplea = request.getParameter("semplea");
        String rbono = request.getParameter("rbono");
        String realizapracticas = request.getParameter("realizapracticas");
        String horasprac = request.getParameter("horasprac");
        String institucionpracticas = request.getParameter("institucionpracticas");
        String secpract = request.getParameter("secpract");
        String tipobeca = request.getParameter("tipobeca");
        String primer = request.getParameter("primer");
        String segunda = request.getParameter("segunda");
        String tercera = request.getParameter("tercera");
        String cuarta = request.getParameter("cuarta");
        String quinta = request.getParameter("quinta");
        String sexta = request.getParameter("sexta");
        Double montobeca = Double.parseDouble(request.getParameter("montobeca"));
        String porcentage = request.getParameter("porcentage");
        String porcentagedebeca = request.getParameter("porcentagedebeca");
        String tfinabeca = request.getParameter("tfinabeca");
        Double valorbeca = Double.parseDouble(request.getParameter("valorbeca"));
        String vinculacion = request.getParameter("vinculacion");
        String proyectovin = request.getParameter("proyectovin");
        String celectronico = request.getParameter("celectronico");
        String celular = request.getParameter("celular");
        String nfpadre = request.getParameter("nfpadre");
        String frmadre = request.getParameter("frmadre");
        Double ingrohogar = Double.parseDouble(request.getParameter("ingrohogar"));
        String mhohar = request.getParameter("mhohar");
        String idfic = request.getParameter("ids");
        
            System.out.println("editar");
            int fich = Integer.parseInt(idfic);
            ficha newficha = new ficha(fich ,tipdoc, cedu, priape, segape, prinom, segnom, sexo, genero, estadoc, etnia, PuebloN, tsangre, tdiscacidad, porcdiscacidad, nroc, tdisc, fnaci, paisnac, cannac, parecid, provres, canresi, tcolegio, mocarrera, jcarrera, finicio, fmatricula, tmatricula, nacademico, semanaperiodo, apmateria, paralelo, apgratuidad, rpdiferecial, esdedica, semplea, rbono, realizapracticas, horasprac, institucionpracticas, secpract, tipobeca, primer, segunda, tercera, cuarta, quinta, sexta, montobeca, porcentage, porcentagedebeca, tfinabeca, valorbeca, vinculacion, proyectovin, celectronico, celular, nfpadre, frmadre, ingrohogar, mhohar);
            try {
                fichdao.editarficha(newficha);
                mensaje = "Los datos se actualizaron correctamente";
            } catch (Exception e) {
                System.out.println("Error: " + e);
                mensaje = "Ocurrió un error al actualizar los datos";
            }
            List<ficha> listaficha = fichdao.listar();
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("listaficha", listaficha);
            RequestDispatcher dispatcher = request.getRequestDispatcher(vistaEstudiantes);
            dispatcher.forward(request, response);
    }
    
    private void editarvalidacion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //PARAMETROS DEL FORMULARIO
        String nomb = request.getParameter("nombre");
        String apel = request.getParameter("apelli");
        String cedu = request.getParameter("cedula");
        String descrip = request.getParameter("estado");
        String obser = request.getParameter("observ");
        String idvalid = request.getParameter("id");
        
            System.out.println("Editar");
            int val = Integer.parseInt(idvalid);
            validacionbecas newvalidacion = new validacionbecas(val,descrip, obser, nomb,apel,cedu);
            
            try {
                valdao.editarvalidaciones(newvalidacion);
                mensaje = "Los datos se actualizaron correctamente";
            } catch (Exception e) {
                System.out.println("Error: " + e);
                mensaje = "Ocurrió un error al actualizar los datos";
            }
            List<validacionbecas> listavali = valdao.listarvali();
        List<consultas> listasolicitud = solidao.listarlistasolicitud();
        request.setAttribute("listaconsulta", listasolicitud);

        request.setAttribute("listavalidaciones", listavali);
        request.setAttribute("mensaje", mensaje);

            RequestDispatcher dispatcher = request.getRequestDispatcher(vistabecas);
            dispatcher.forward(request, response);
    }
    
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
