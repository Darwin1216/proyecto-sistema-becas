/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.ControladorAcceso;
import modelo.Validacion;
import modelo.fichaDao;
import modelo.solicitudDAO;

/**
 *
 * @author Pato
 */
public class myServlet extends HttpServlet {

//    fichaDao ficha;
//    solicitudDAO soli;
    String mensaje;
    
    // metodo para dar orden de abrir la conexion
//    public void init() throws ServletException {
//        // datos xml
//        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
//        String jdbcUSERName = getServletContext().getInitParameter("jdbcUSERName");
//        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
//        try {
//            ficha = new fichaDao(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
////            soli = new solicitudDAO(jdbcURL, jdbcUSERName, jdbcPassword); // Instancio el Dao
//        } catch (SQLException ex) {
//            Logger.getLogger(myServlet.class.getName()).log(Level.SEVERE, null, ex);
//            mensaje= "Error de Conexion";
//        }
//        mensaje = "Listos para iniciar conexión";
//    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet myServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet myServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        //CREACION DE VARIABLES D ETIPO STRING Y ALMACENAR MJS
        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        String usu, pass, op, resultado = "incorrecto";
        String mensaje = "";
        // Zona captura de datos procesamiento, como autenticación, validación o ejecución de cierta lógica de negocio basada en los datos recibidos
        usu = request.getParameter("usuario");
        pass = request.getParameter("contrasenia");
        op = request.getParameter("accion");
        //SI CUMPLE SE CREA UNA UNA VALIDACION
        if (op.equalsIgnoreCase("INGRESAR")) {  
            Validacion validador = new Validacion(usu, pass);
            resultado = validador.ValidacionUsuario();
            if (resultado.equalsIgnoreCase("Acceso Correcto")) {
                // LOGICA ACCESO CORRECTO
                resultado = "Acceso Correcto. Conexion Exitosa.";
                ControladorAcceso.resetIntentosRestantes(getServletContext());
                request.setAttribute("mensaje", resultado);
                request.getRequestDispatcher("home.jsp");
                dispatcher.forward(request, response);
                // SE REDIRIGE A LA NUEVA INTERFAZ
                return; // Importante:  evitar que se muestre el JSP 
            } else {
                // LOGICA DE ACCESO CORRECTO
                int intentosRestantes = ControladorAcceso.decrementarIntentosRestantes(getServletContext());
                if (intentosRestantes > 0) {
                    mensaje = " Intentos restantes: " + intentosRestantes;
                } else {
                    mensaje = "Acceso bloqueado.intentarlo nuevamente.";
                }
            }
        }
        // ZONA DE RESPUESTA A LA VISTA
        request.setAttribute("cajitarespuesta", resultado);
        request.setAttribute("mensajesBD", mensaje);
        RequestDispatcher objdp = request.getRequestDispatcher("index.jsp");
        objdp.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
