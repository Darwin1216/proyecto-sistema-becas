package modelo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    private String jdbcURL;
    private String jdbcUSERName;
    private String jdbcPassword;
    private Connection jdbcConnection;
    
    //constructor
    public Conexion(String jdbcURL, String jdbcUSERName, String jdbcPassword ){
        this.jdbcURL = jdbcURL;
        this.jdbcUSERName = jdbcUSERName;
        this.jdbcPassword = jdbcPassword;
        
    }
    //metodo que abra la conexion bd
    public Connection connection() throws SQLException {
        if(jdbcConnection == null || jdbcConnection.isClosed()){
          try{
              Class.forName("com.mysql.cj.jdbc.Driver");
              System.out.println("Conexion exitosa");
          }  
          catch(ClassNotFoundException er){
              System.out.println("Error de conexion: "+er);
              throw new SQLException(er);
          }
          jdbcConnection = (Connection) DriverManager.getConnection(jdbcURL, jdbcUSERName,jdbcPassword );
        }
        return jdbcConnection;
        
    }
    //metodo que cierra la conexion bd
    public void disconnect()throws SQLException{
        if(jdbcConnection != null && jdbcConnection.isClosed()){
            jdbcConnection.close();//cierra conexion a la base            
        }
    }
    //metodo para conocer los datos de la conexión
    public Connection getjdbcConnection(){
        return jdbcConnection;
    }
}