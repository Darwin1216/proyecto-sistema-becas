
package modelo;

import javax.servlet.ServletContext;

 
//proporciona métodos para gestionar y controlar el número de intentos restantes para acceder a una aplicación web
public class ControladorAcceso {
    private static final int MAX_INTENTOS = 3;

    // Método para obtener el número actual de intentos restantes
    public static int getIntentosRestantes(ServletContext context) {
        Integer intentosRestantes = (Integer) context.getAttribute("intentosRestantes");
        return (intentosRestantes != null) ? intentosRestantes : MAX_INTENTOS;
    }

    // Método para decrementar el número de intentos restantes
    public static int decrementarIntentosRestantes(ServletContext context) {
        int intentosRestantes = getIntentosRestantes(context);
        intentosRestantes--;
        context.setAttribute("intentosRestantes", intentosRestantes);
        return intentosRestantes;
    }

    // Método para reiniciar el número de intentos restantes
    public static void resetIntentosRestantes(ServletContext context) {
        context.setAttribute("intentosRestantes", MAX_INTENTOS);
    }
}
