
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class solicitudDAO {
    private Conexion con;
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;

    public solicitudDAO (String jdbcURL, String jdbcUsername, String jdbcPassword) throws SQLException {
        con = new Conexion(jdbcURL, jdbcUsername, jdbcPassword);
        conn = con.connection();
        con.getjdbcConnection();
    }
    
//    public boolean insertarsolicitud(consultas objsoli) {
//    boolean estado = false;
//    PreparedStatement pstmt = null;
//    String sql = "INSERT INTO solicitudes (tipo, certificadoestudiante, Copiacedu, certificadoIES, otrosdocumentos, fk_ficha) "
//            + "VALUES (?, ?, ?, ?, ?, ?)";
//    try {
//        con.connection();
//        pstmt = con.getjdbcConnection().prepareStatement(sql);
//        pstmt.setString(1, objsoli.getTipo());
//        pstmt.setString(2, objsoli.getCertificadoestudiante());
//        pstmt.setString(3, objsoli.getCopiacedula());
//        pstmt.setString(4, objsoli.getCertifiadoIES());
//        pstmt.setString(5, objsoli.getOtrosdocumentos());
//        pstmt.setInt(6, objsoli.getFk_ficha());
//
//        pstmt.executeUpdate();
//        estado = true;
//    } catch (SQLException objerr) {
//        estado = false;
//        objerr.printStackTrace();
//    } finally {
//        try {
//            if (pstmt != null) {
//                pstmt.close();
//            }
//            con.disconnect();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    return estado;
//}
    
    public boolean insertarsolicitud(consultas objcon) {
        boolean estado = false;//variable para insertar la inserccion de datos  
        Statement stm; //interpreta cod SQL desde JAVA
        String sql = "insert into solicitudes values(null, "
                + "'" + objcon.getTipo() + "',"
                + "'" + objcon.getCertificadoestudiante() + "',"
                + "'" + objcon.getCopiacedula() + "',"
                + "'" + objcon.getCertifiadoIES() + "',"
                + "'" + objcon.getOtrosdocumentos() + "',"
                + "'" + objcon.getFk_ficha() +"');";
        try {
            con.connection();//abrir la conexion
            stm = con.getjdbcConnection().createStatement();
            stm.executeUpdate(sql); //ejecuto el script de la variable SQL
            estado = true; // si se ejecuta la inserccion 
            stm.close();
            con.disconnect();// cierra la conexion

        } catch (SQLException objerr) {
            estado = false;// no se ejecuto la inserccion
            objerr.printStackTrace();//imprimo toda la traza del error
        }
        return estado;
        }
    
    
    public List listar() {
    List<consultas> listaconsulta = new ArrayList<>();
    String sSQL;
        sSQL = "SELECT * FROM solicitudes";
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
            consultas cons = new consultas();
                cons.setIdbeca(Integer.parseInt(rs.getString("idBeca")));
                cons.setTipo(rs.getString("tipo"));;
                cons.setCertificadoestudiante(rs.getString("certificadoestudiante"));
                cons.setCopiacedula(rs.getString("Copiacedu"));
                cons.setCertifiadoIES(rs.getString("certificadoIES"));
                cons.setOtrosdocumentos(rs.getString("otrosdocumentos"));
                cons.setFk_ficha(Integer.parseInt(rs.getString("fk_ficha")));
            listaconsulta.add(cons);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Solicitudes. Número de elementos en la lista: " + listaconsulta.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Solicitudes: " + e);
            System.out.println("------------------------------------------");
        }
        return listaconsulta;
    }
    
    
    
    
    //==================================== METODO PARA LISTAR EN LA TABLA SOLICITUDES ================================//
    public List listarlistasolicitud() {
    List<consultas> listasolicitud = new ArrayList<>();
    String sSQL;
        sSQL = "SELECT * FROM viewsolicitudes ORDER BY id";
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
            consultas cons = new consultas();
                cons.setIdbeca(Integer.parseInt(rs.getString("id")));
                cons.setTipo(rs.getString("tipo"));;
                cons.setNomb_ficha(rs.getString("nombre"));
                cons.setApel_ficha(rs.getString("apellido"));
                cons.setCedu_ficha(rs.getString("cedula"));
                cons.setCorreo_ficha(rs.getString("correo"));
            listasolicitud.add(cons);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Solicitudes. Número de elementos en la lista: " + listasolicitud.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Solicitudes: " + e);
            System.out.println("------------------------------------------");
        }
        return listasolicitud;
    }
    //==================================================================================================================//
    
    
    
    public consultas listaridsolicitud(int id) {
    consultas con = new consultas();
    String sSQL;
    sSQL = "SELECT * FROM viewsolicitudes WHERE id=" + id;
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
            con.setTipo(rs.getString(2));
            con.setCertificadoestudiante(rs.getString(3));
            con.setCopiacedula(rs.getString(4));
            con.setCertifiadoIES(rs.getString(5));
            con.setOtrosdocumentos(rs.getString(6));
        }
        System.out.println("------------------------------------------");
        System.out.println(sSQL);
        System.out.println("Se ha listado en Solicitudes: ");
        System.out.println("------------------------------------------");
    } catch (SQLException e) {
        System.out.println("------------------------------------------");
        System.out.println("Error al listar en Solicitudes: " + e);
        System.out.println("------------------------------------------");
    }
    return con;
}
    
//    public boolean Eliminarsoli(int idsoli){
//        //Zona de objetos
//        boolean estado = false;
//        Statement stm;
//        String sql = "CALL eliminarsolicitud(?)";
//        try {
//            con.connection();
//            stm = con.getjdbcConnection().createStatement();
//            stm.executeUpdate(sql);
//            estado = true;
//            stm.close();
//            con.disconnect();
//        } catch (SQLException e) {
//            estado = false;
//            e.printStackTrace();//imprimo toda la traza del error en el servidor
//            System.out.println("------------------------------------------------");
//            System.out.println("Ha ocurrido un error al eliminar la solicitud " + e);
//            System.out.println("------------------------------------------------");
//        }
//        return estado;
//    }
    
    public boolean Eliminarsoli(int idsoli) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("CALL eliminarsolicitud(?)");
            ps.setInt(1, idsoli);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException e) {
            System.out.println("------------------------------------------------");
            System.out.println("Ha ocurrido un error al eliminar la solicitud " + e);
            System.out.println("------------------------------------------------");
        }
        return false;

    }
    
    
    
    public boolean Actualizar(consultas objactualizar){
        //Zona de variables
        boolean estado = false;
        Statement stm;
        String sql = "UPDATE solicitudes SET tipo = '"+objactualizar.getTipo()+"', `certificadoestudiante` = '"+objactualizar.getCertificadoestudiante()+"', `Copiacedu` = '"+objactualizar.getCopiacedula()+"',`certificadoIES` = '"+objactualizar.getCertifiadoIES()+"',`otrosdocumentos` = '"+objactualizar.getOtrosdocumentos()+"', WHERE idBeca = "+objactualizar.getIdbeca();
     try {
            con.connection();
            stm = con.getjdbcConnection().createStatement();
            stm.executeUpdate(sql);
            estado = true;
            stm.close();
            con.disconnect();
            
            
        } catch (SQLException err) {
            estado = false;
             err.printStackTrace();//imprimo toda la traza del error en el servidor
        }
        return estado;
    }
    
    
    //--------------------------------------------------------------------------------------------------------//
    //================================= METODO PARA ACTUALIZAR LA SOLICITUD ==================================//
    //--------------------------------------------------------------------------------------------------------//
    public boolean editarsolicitud(consultas idsoli) {
    PreparedStatement ps;
    try {
        ps = conn.prepareStatement("call actualizarsolicitud(?,?,?,?,?,?,?,?,?)");
        ps.setString(1, idsoli.getNomb_ficha());
        ps.setString(2, idsoli.getApel_ficha());
        ps.setString(3, idsoli.getCedu_ficha());  // Agregué los paréntesis aquí
        ps.setString(4, idsoli.getTipo());
        ps.setString(5, idsoli.getCertificadoestudiante());
        ps.setString(6, idsoli.getCopiacedula());
        ps.setString(7, idsoli.getCertifiadoIES());
        ps.setString(8, idsoli.getOtrosdocumentos());
        ps.setInt(9, idsoli.getIdbeca());  // Asumí que idsoli es el ID que estás usando en tu procedimiento almacenado
        ps.execute();
        ps.close();
        return true;
    } catch (SQLException e) {
        System.out.println("------------------------------------------------");
        System.out.println("Ha ocurrido un error al editar la solicitud " + e);
        System.out.println("------------------------------------------------");
    }
    return false;
}
    //----------------------------------------------------------------------------------------==============-//

    
    //======================= METODO PARA BUSCAR POR LA ID EN SOLICITUDES ===========================//
    public List buscar(int id) {
    List<consultas> listabusqsoli = new ArrayList<>();
    String sSQL;
        sSQL = "SELECT * FROM viewsolicitudes WHERE id="+id;
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
            consultas busq = new consultas();
                busq.setIdbeca(Integer.parseInt(rs.getString("id")));
                busq.setTipo(rs.getString("tipo"));
                busq.setNomb_ficha(rs.getString("nombre"));
                busq.setApel_ficha(rs.getString("apellido"));
                busq.setCedu_ficha(rs.getString("cedula"));
                busq.setCorreo_ficha(rs.getString("correo"));
            listabusqsoli.add(busq);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Solicitudes. Número de elementos en la lista: " + listabusqsoli.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Solicitudes: " + e);
            System.out.println("------------------------------------------");
        }
        return listabusqsoli;
    }
    //==========================================================================================================//
    
    
    
    //---------------------------------------------------------------------------------------------------------//
    //======================= METODO PARA MOSTRAR LOS DATOS DE LA TABLA PARA EDITAR ===========================//
    //---------------------------------------------------------------------------------------------------------//
    public consultas buscarsoli(int id) {
        consultas busq =new consultas();
        String sSQL;
        sSQL = "SELECT * FROM viewsolicitudes WHERE id="+id+";";
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
                busq = new consultas();
                busq.setIdbeca(Integer.parseInt(rs.getString("id")));
                busq.setTipo(rs.getString("tipo"));
                busq.setNomb_ficha(rs.getString("nombre"));
                busq.setApel_ficha(rs.getString("apellido"));
                busq.setCedu_ficha(rs.getString("cedula"));
                busq.setCorreo_ficha(rs.getString("correo"));
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Solicitudes.");
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Solicitudes: " + e);
            System.out.println("------------------------------------------");
        }
        return busq;
    }
    //=============================================================================================================//
    
}
