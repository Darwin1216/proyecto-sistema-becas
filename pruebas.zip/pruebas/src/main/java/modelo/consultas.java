
package modelo;

public class consultas {
    private int idbeca;
    private String tipo;
    private String certificadoestudiante;
    private String copiacedula;
    private String certifiadoIES;
    private String otrosdocumentos;
    
    private int fk_ficha;
    private String nomb_ficha;
    private String apel_ficha;
    private String cedu_ficha;
    private String correo_ficha;
    

    public consultas() {
    }

    
    public consultas(int idbeca, String tipo, String certificadoestudiante, String copiacedula, String certifiadoIES, String otrosdocumentos, int fk_ficha) {
        this.idbeca = idbeca;
        this.tipo = tipo;
        this.certificadoestudiante = certificadoestudiante;
        this.copiacedula = copiacedula;
        this.certifiadoIES = certifiadoIES;
        this.otrosdocumentos = otrosdocumentos;
        this.fk_ficha = fk_ficha;
    }

    public consultas(String tipo, String certificadoestudiante, String copiacedula, String certifiadoIES, String otrosdocumentos, int fk_ficha) {
        this.tipo = tipo;
        this.certificadoestudiante = certificadoestudiante;
        this.copiacedula = copiacedula;
        this.certifiadoIES = certifiadoIES;
        this.otrosdocumentos = otrosdocumentos;
        this.fk_ficha = fk_ficha;
    }

    public consultas(int idbeca, String tipo, String certificadoestudiante, String copiacedula, String certifiadoIES, String otrosdocumentos, int fk_ficha, String nomb_ficha, String apel_ficha, String cedu_ficha) {
        this.idbeca = idbeca;
        this.tipo = tipo;
        this.certificadoestudiante = certificadoestudiante;
        this.copiacedula = copiacedula;
        this.certifiadoIES = certifiadoIES;
        this.otrosdocumentos = otrosdocumentos;
        this.fk_ficha = fk_ficha;
        this.nomb_ficha = nomb_ficha;
        this.apel_ficha = apel_ficha;
        this.cedu_ficha = cedu_ficha;
    }

    public consultas(int idbeca, String tipo, String nomb_ficha, String apel_ficha, String cedu_ficha, String correo_ficha) {
        this.idbeca = idbeca;
        this.tipo = tipo;
        this.nomb_ficha = nomb_ficha;
        this.apel_ficha = apel_ficha;
        this.cedu_ficha = cedu_ficha;
        this.correo_ficha = correo_ficha;
    }

    public consultas(int idbeca, String tipo, String certificadoestudiante, String copiacedula, String certifiadoIES, String otrosdocumentos, String nomb_ficha, String apel_ficha, String cedu_ficha) {
        this.idbeca = idbeca;
        this.tipo = tipo;
        this.certificadoestudiante = certificadoestudiante;
        this.copiacedula = copiacedula;
        this.certifiadoIES = certifiadoIES;
        this.otrosdocumentos = otrosdocumentos;
        this.nomb_ficha = nomb_ficha;
        this.apel_ficha = apel_ficha;
        this.cedu_ficha = cedu_ficha;
    }
    

    public String getCorreo_ficha() {
        return correo_ficha;
    }

    public void setCorreo_ficha(String correo_ficha) {
        this.correo_ficha = correo_ficha;
    }
    
    public int getIdbeca() {
        return idbeca;
    }

    public void setIdbeca(int idbeca) {
        this.idbeca = idbeca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCertificadoestudiante() {
        return certificadoestudiante;
    }

    public void setCertificadoestudiante(String certificadoestudiante) {
        this.certificadoestudiante = certificadoestudiante;
    }

    public String getCopiacedula() {
        return copiacedula;
    }

    public void setCopiacedula(String copiacedula) {
        this.copiacedula = copiacedula;
    }

    public String getCertifiadoIES() {
        return certifiadoIES;
    }

    public void setCertifiadoIES(String certifiadoIES) {
        this.certifiadoIES = certifiadoIES;
    }

    public String getOtrosdocumentos() {
        return otrosdocumentos;
    }

    public void setOtrosdocumentos(String otrosdocumentos) {
        this.otrosdocumentos = otrosdocumentos;
    }

    public int getFk_ficha() {
        return fk_ficha;
    }

    public void setFk_ficha(int fk_ficha) {
        this.fk_ficha = fk_ficha;
    }

    public String getNomb_ficha() {
        return nomb_ficha;
    }

    public void setNomb_ficha(String nomb_ficha) {
        this.nomb_ficha = nomb_ficha;
    }

    public String getApel_ficha() {
        return apel_ficha;
    }

    public void setApel_ficha(String apel_ficha) {
        this.apel_ficha = apel_ficha;
    }

    public String getCedu_ficha() {
        return cedu_ficha;
    }

    public void setCedu_ficha(String cedu_ficha) {
        this.cedu_ficha = cedu_ficha;
    }
    
    
}
