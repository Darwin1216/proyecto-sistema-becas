
package modelo;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class fichaDao {

    public fichaDao() {
    }

    private Conexion con;
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;

    public fichaDao (String jdbcURL, String jdbcUsername, String jdbcPassword) throws SQLException {
        con = new Conexion(jdbcURL, jdbcUsername, jdbcPassword);
        conn = con.connection();
        con.getjdbcConnection();
    }
    
    
    
    //----------------------------------------------------------------------------------------------------------------------//
    //===================================== METODO PARA INSERTAR EN LA FICHA ESTUDIANTE ====================================//
    //----------------------------------------------------------------------------------------------------------------------//
    public boolean insertarficha(ficha objfi) {
        boolean estado = false;//variable para insertar la inserccion de datos  
        Statement stm; //interpreta cod SQL desde JAVA
        String sql = "insert into fichaestudiante values(null, "
                + "'" + objfi.getTipodeDocumento() + "',"
                + "'" + objfi.getNúmerodocumentoidentificación() + "',"
                + "'" + objfi.getPrimerapellidoestudiante() + "',"
                + "'" + objfi.getSegundoapellidodelestudiante() + "',"
                + "'" + objfi.getPrimernombredelestudiante() + "',"
                + "'" + objfi.getSegundonombredelestudiante() + "',"
                + "'" + objfi.getSexo() + "',"
                + "'" + objfi.getGénerodelestudiante() + "',"
                + "'" + objfi.getEstadocivil() + "',"
                + "'" + objfi.getEtnia() + "',"
                + "'" + objfi.getPuebloNacionales() + "',"
                + "'" + objfi.getTipodesangre() + "',"
                + "'" + objfi.getTienediscapacidad() + "',"
                + "'" + objfi.getPorcentajedediscapacidad() + "',"
                + "'" + objfi.getNroCarnetCONADIS() + "',"
                + "'" + objfi.getTipodediscapacidad() + "',"
                + "'" + objfi.getFechadenacimiento() + "',"
                + "'" + objfi.getPaisnacionalidad() + "',"
                + "'" + objfi.getCantóndenacimiento() + "',"
                + "'" + objfi.getPaísderesidencia() + "',"
                + "'" + objfi.getProvinciaderesidencia() + "',"
                + "'" + objfi.getCantónderesidencia() + "',"
                + "'" + objfi.getTipodeColegio() + "',"
                + "'" + objfi.getModalidaddelaCarrera() + "',"
                + "'" + objfi.getJornadadelaCarrera() + "',"
                + "'" + objfi.getFechainicióestudiantelacarrera() + "',"
                + "'" + objfi.getFechadematrícula() + "',"
                + "'" + objfi.getTipodematrícula() + "',"
                + "'" + objfi.getNivelAcadémico() + "',"
                + "'" + objfi.getNúmerosemanasduraciónperíodoacadémico() + "',"
                + "'" + objfi.getHarepetidounamateria() + "',"
                + "'" + objfi.getParalelo() + "',"
                + "'" + objfi.getHaperdidolagratuidad() + "',"
                + "'" + objfi.getPoseepensióndiferenciada() + "',"
                + "'" + objfi.getElestudianteseencuentradedicadoa() + "',"
                + "'" + objfi.getElestudianteparaquéempleasusingresos() + "',"
                + "'" + objfi.getLafamiliadelestudianterecibeelbonodedesarrollohumano() + "',"
                + "'" + objfi.getElestudianteharealizadoprácticaspreprofesionales() + "',"
                + "'" + objfi.getHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante() + "',"
                + "'" + objfi.getTipodeinstituciónenelquerealizalasprácticaspreprofesionales() + "',"
                + "'" + objfi.getSectoreconómicorealizólasprácticaspreprofesionale() + "',"
                + "'" + objfi.getTipodebecaquerecibeelestudiante() + "',"
                + "'" + objfi.getPrimerarazóndebeca() + "',"
                + "'" + objfi.getSegundarazóndebeca() + "',"
                + "'" + objfi.getTercerarazóndebeca() + "',"
                + "'" + objfi.getCuartarazóndebeca() + "',"
                + "'" + objfi.getQuintarazóndebeca() + "',"
                + "'" + objfi.getSextarazóndebeca() + "',"
                + "'" + objfi.getValordelmontodelabeca() + "',"
                + "'" + objfi.getPorcentajebecaquecubreelvalordelarancel() + "',"
                + "'" + objfi.getPorcentajedelabecaquecubrelamanutención() + "',"
                + "'" + objfi.getTipodefinanciamientodelabeca() + "',"
                + "'" + objfi.getValordelmontodelaayudaeconómica() + "',"
                + "'" + objfi.getHaparticicipadoduranteperiodoproyectovinculaciónsocial() + "',"
                + "'" + objfi.getAlcanceproyectovinculacionsociedad() + "',"
                + "'" + objfi.getCorreoelectrónicodelestudiante() + "',"
                + "'" + objfi.getNúmerodecelulardelestudiante() + "',"
                + "'" + objfi.getNiveldeformacióndelpadre() + "',"
                + "'" + objfi.getNiveformaciónmadre() + "',"
                + "'" + objfi.getIngresosdelhogar() + "',"
                + "'" + objfi.getNúmerodemiembrosdelhogar() +"');";
        try {
            con.connection();//abrir la conexion
            stm = con.getjdbcConnection().createStatement();
            stm.executeUpdate(sql); //ejecuto el script de la variable SQL
            estado = true; // si se ejecuta la inserccion 
            stm.close();
            con.disconnect();// cierra la conexion

        } catch (SQLException objerr) {
            estado = false;// no se ejecuto la inserccion
            objerr.printStackTrace();//imprimo toda la traza del error
        }
        return estado;
    }
    //================================================================================================================//
    
    
    
    //----------------------------------------------------------------------------------------------------------------//
    //=================================== METODO PARA LISTAR EN LA FICHA ESTUDIANTE ==================================//
    //----------------------------------------------------------------------------------------------------------------//
        public List listar() {
        List<ficha> listaficha = new ArrayList<>();
        String sSQL;
        sSQL = "SELECT * FROM fichaestudiante";
        try {
            ps = conn.prepareStatement(sSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                ficha fi = new ficha();
                fi.setIdficha(Integer.parseInt(rs.getString("idficha")));
                fi.setTipodeDocumento(rs.getString("TipodeDocumento"));
                fi.setNúmerodocumentoidentificación(rs.getString("Númerodocumentoidentificación"));
                fi.setPrimerapellidoestudiante(rs.getString("primerapellidoestudiante"));
                fi.setSegundoapellidodelestudiante(rs.getString("Segundoapellidodelestudiante"));
                fi.setPrimernombredelestudiante(rs.getString("Primernombredelestudiante"));
                fi.setSegundonombredelestudiante(rs.getString("Segundonombredelestudiante"));
                fi.setSexo(rs.getString("Sexo"));
                fi.setGénerodelestudiante(rs.getString("Génerodelestudiante"));
                fi.setEstadocivil(rs.getString("Estadocivil"));
                fi.setEtnia(rs.getString("Etnia"));
                fi.setPuebloNacionales(rs.getString("PuebloNacionales"));
                fi.setTipodesangre(rs.getString("Tipodesangre"));
                fi.setTienediscapacidad(rs.getString("Tienediscapacidad"));
                fi.setPorcentajedediscapacidad(rs.getString("Porcentajedediscapacidad"));
                fi.setNroCarnetCONADIS(rs.getString("NroCarnetCONADIS"));
                fi.setTipodediscapacidad(rs.getString("Tipodediscapacidad"));
                fi.setFechadenacimiento(rs.getString("Fechadenacimiento"));
                fi.setPaisnacionalidad(rs.getString("Paisnacionalidad"));
                fi.setCantóndenacimiento(rs.getString("Cantóndenacimiento"));
                fi.setPaísderesidencia(rs.getString("Paísderesidencia"));
                fi.setProvinciaderesidencia(rs.getString("Provinciaderesidencia"));
                fi.setCantónderesidencia(rs.getString("Cantónderesidencia"));
                fi.setTipodeColegio(rs.getString("TipodeColegio"));
                fi.setModalidaddelaCarrera(rs.getString("ModalidaddelaCarrera"));
                fi.setJornadadelaCarrera(rs.getString("JornadadelaCarrera"));
                fi.setFechainicióestudiantelacarrera(rs.getString("Fechainicióestudiantelacarrera"));
                fi.setFechadematrícula(rs.getString("Fechadematrícula"));
                fi.setTipodematrícula(rs.getString("Tipodematrícula"));
                fi.setNivelAcadémico(rs.getString("NivelAcadémico"));
                fi.setNúmerosemanasduraciónperíodoacadémico(rs.getString("Númerosemanasduraciónperíodoacadémico"));
                fi.setHarepetidounamateria(rs.getString("Harepetidounamateria"));
                fi.setParalelo(rs.getString("Paralelo"));
                fi.setHaperdidolagratuidad(rs.getString("Haperdidolagratuidad"));
                fi.setPoseepensióndiferenciada(rs.getString("Poseepensióndiferenciada"));
                fi.setElestudianteseencuentradedicadoa(rs.getString("Elestudianteseencuentradedicadoa"));
                fi.setElestudianteparaquéempleasusingresos(rs.getString("Elestudianteparaquéempleasusingresos"));
                fi.setLafamiliadelestudianterecibeelbonodedesarrollohumano(rs.getString("Lafamiliadelestudianterecibeelbonodedesarrollohumano"));
                fi.setElestudianteharealizadoprácticaspreprofesionales(rs.getString("Elestudianteharealizadoprácticaspreprofesionales"));
                fi.setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(rs.getString("Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante"));
                fi.setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(rs.getString("Tipodeinstituciónenelquerealizalasprácticaspreprofesionales"));
                fi.setSectoreconómicorealizólasprácticaspreprofesionale(rs.getString("Sectoreconómicorealizólasprácticaspreprofesionale"));
                fi.setTipodebecaquerecibeelestudiante(rs.getString("Tipodebecaquerecibeelestudiante"));
                fi.setPrimerarazóndebeca(rs.getString("Primerarazóndebeca"));
                fi.setSegundarazóndebeca(rs.getString("Segundarazóndebeca"));
                fi.setTercerarazóndebeca(rs.getString("Tercerarazóndebeca"));
                fi.setCuartarazóndebeca(rs.getString("Cuartarazóndebeca"));
                fi.setQuintarazóndebeca(rs.getString("Quintarazóndebeca"));
                fi.setSextarazóndebeca(rs.getString("Sextarazóndebeca"));
                fi.setValordelmontodelabeca(Double.parseDouble(rs.getString("Valordelmontodelabeca")));
                fi.setPorcentajebecaquecubreelvalordelarancel(rs.getString("Porcentajebecaquecubreelvalordelarancel"));
                fi.setPorcentajedelabecaquecubrelamanutención(rs.getString("Porcentajedelabecaquecubrelamanutención"));
                fi.setTipodefinanciamientodelabeca(rs.getString("Tipodefinanciamientodelabeca"));
                fi.setValordelmontodelaayudaeconómica(Double.parseDouble(rs.getString("Valordelmontodelaayudaeconómica")));
                fi.setHaparticicipadoduranteperiodoproyectovinculaciónsocial(rs.getString("Haparticicipadoduranteperiodoproyectovinculaciónsocial"));
                fi.setAlcanceproyectovinculacionsociedad(rs.getString("Alcanceproyectovinculacionsociedad"));
                fi.setCorreoelectrónicodelestudiante(rs.getString("Correoelectrónicodelestudiante"));
                fi.setNúmerodecelulardelestudiante(rs.getString("Númerodecelulardelestudiante"));
                fi.setNiveldeformacióndelpadre(rs.getString("Niveldeformacióndelpadre"));
                fi.setNiveformaciónmadre(rs.getString("Niveformaciónmadre"));
                fi.setIngresosdelhogar(Double.parseDouble(rs.getString("Ingresosdelhogar")));
                fi.setNúmerodemiembrosdelhogar(rs.getString("Númerodemiembrosdelhogar"));
                listaficha.add(fi);
            }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en la Ficha. Número de elementos en la lista: " + listaficha.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en la Ficha: " + e);
            System.out.println("------------------------------------------");
        }
        return listaficha;
    }
    //========================================================================================================================//
    
    
        
        
    //----------------------------------------------------------------------------------------------------------------------//
    //====================================== METODO PARA BUSCAR AL ESTUDIANTE POR LA ID ====================================//
    //----------------------------------------------------------------------------------------------------------------------//
    public List buscarestudiante(int id) {
        List<ficha> buscarficha = new ArrayList<>();
        String sSQL;
        sSQL = "SELECT * FROM fichaestudiante WHERE idficha="+id;
        try {
            ps = conn.prepareStatement(sSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                ficha fi = new ficha();
                fi.setIdficha(Integer.parseInt(rs.getString("idficha")));
                fi.setTipodeDocumento(rs.getString("TipodeDocumento"));
                fi.setNúmerodocumentoidentificación(rs.getString("Númerodocumentoidentificación"));
                fi.setPrimerapellidoestudiante(rs.getString("primerapellidoestudiante"));
                fi.setSegundoapellidodelestudiante(rs.getString("Segundoapellidodelestudiante"));
                fi.setPrimernombredelestudiante(rs.getString("Primernombredelestudiante"));
                fi.setSegundonombredelestudiante(rs.getString("Segundonombredelestudiante"));
                fi.setSexo(rs.getString("Sexo"));
                fi.setGénerodelestudiante(rs.getString("Génerodelestudiante"));
                fi.setEstadocivil(rs.getString("Estadocivil"));
                fi.setEtnia(rs.getString("Etnia"));
                fi.setPuebloNacionales(rs.getString("PuebloNacionales"));
                fi.setTipodesangre(rs.getString("Tipodesangre"));
                fi.setTienediscapacidad(rs.getString("Tienediscapacidad"));
                fi.setPorcentajedediscapacidad(rs.getString("Porcentajedediscapacidad"));
                fi.setNroCarnetCONADIS(rs.getString("NroCarnetCONADIS"));
                fi.setTipodediscapacidad(rs.getString("Tipodediscapacidad"));
                fi.setFechadenacimiento(rs.getString("Fechadenacimiento"));
                fi.setPaisnacionalidad(rs.getString("Paisnacionalidad"));
                fi.setCantóndenacimiento(rs.getString("Cantóndenacimiento"));
                fi.setPaísderesidencia(rs.getString("Paísderesidencia"));
                fi.setProvinciaderesidencia(rs.getString("Provinciaderesidencia"));
                fi.setCantónderesidencia(rs.getString("Cantónderesidencia"));
                fi.setTipodeColegio(rs.getString("TipodeColegio"));
                fi.setModalidaddelaCarrera(rs.getString("ModalidaddelaCarrera"));
                fi.setJornadadelaCarrera(rs.getString("JornadadelaCarrera"));
                fi.setFechainicióestudiantelacarrera(rs.getString("Fechainicióestudiantelacarrera"));
                fi.setFechadematrícula(rs.getString("Fechadematrícula"));
                fi.setTipodematrícula(rs.getString("Tipodematrícula"));
                fi.setNivelAcadémico(rs.getString("NivelAcadémico"));
                fi.setNúmerosemanasduraciónperíodoacadémico(rs.getString("Númerosemanasduraciónperíodoacadémico"));
                fi.setHarepetidounamateria(rs.getString("Harepetidounamateria"));
                fi.setParalelo(rs.getString("Paralelo"));
                fi.setHaperdidolagratuidad(rs.getString("Haperdidolagratuidad"));
                fi.setPoseepensióndiferenciada(rs.getString("Poseepensióndiferenciada"));
                fi.setElestudianteseencuentradedicadoa(rs.getString("Elestudianteseencuentradedicadoa"));
                fi.setElestudianteparaquéempleasusingresos(rs.getString("Elestudianteparaquéempleasusingresos"));
                fi.setLafamiliadelestudianterecibeelbonodedesarrollohumano(rs.getString("Lafamiliadelestudianterecibeelbonodedesarrollohumano"));
                fi.setElestudianteharealizadoprácticaspreprofesionales(rs.getString("Elestudianteharealizadoprácticaspreprofesionales"));
                fi.setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(rs.getString("Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante"));
                fi.setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(rs.getString("Tipodeinstituciónenelquerealizalasprácticaspreprofesionales"));
                fi.setSectoreconómicorealizólasprácticaspreprofesionale(rs.getString("Sectoreconómicorealizólasprácticaspreprofesionale"));
                fi.setTipodebecaquerecibeelestudiante(rs.getString("Tipodebecaquerecibeelestudiante"));
                fi.setPrimerarazóndebeca(rs.getString("Primerarazóndebeca"));
                fi.setSegundarazóndebeca(rs.getString("Segundarazóndebeca"));
                fi.setTercerarazóndebeca(rs.getString("Tercerarazóndebeca"));
                fi.setCuartarazóndebeca(rs.getString("Cuartarazóndebeca"));
                fi.setQuintarazóndebeca(rs.getString("Quintarazóndebeca"));
                fi.setSextarazóndebeca(rs.getString("Sextarazóndebeca"));
                fi.setValordelmontodelabeca(Double.parseDouble(rs.getString("Valordelmontodelabeca")));
                fi.setPorcentajebecaquecubreelvalordelarancel(rs.getString("Porcentajebecaquecubreelvalordelarancel"));
                fi.setPorcentajedelabecaquecubrelamanutención(rs.getString("Porcentajedelabecaquecubrelamanutención"));
                fi.setTipodefinanciamientodelabeca(rs.getString("Tipodefinanciamientodelabeca"));
                fi.setValordelmontodelaayudaeconómica(Double.parseDouble(rs.getString("Valordelmontodelaayudaeconómica")));
                fi.setHaparticicipadoduranteperiodoproyectovinculaciónsocial(rs.getString("Haparticicipadoduranteperiodoproyectovinculaciónsocial"));
                fi.setAlcanceproyectovinculacionsociedad(rs.getString("Alcanceproyectovinculacionsociedad"));
                fi.setCorreoelectrónicodelestudiante(rs.getString("Correoelectrónicodelestudiante"));
                fi.setNúmerodecelulardelestudiante(rs.getString("Númerodecelulardelestudiante"));
                fi.setNiveldeformacióndelpadre(rs.getString("Niveldeformacióndelpadre"));
                fi.setNiveformaciónmadre(rs.getString("Niveformaciónmadre"));
                fi.setIngresosdelhogar(Double.parseDouble(rs.getString("Ingresosdelhogar")));
                fi.setNúmerodemiembrosdelhogar(rs.getString("Númerodemiembrosdelhogar"));
                buscarficha.add(fi);
            }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en la Ficha. Número de elementos en la lista: " + buscarficha.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en la Ficha: " + e);
            System.out.println("------------------------------------------");
        }
        return buscarficha;
    }
   //================================================================================================================//
    
    
    
    //-----------------------------------------------------------------------------------------------------------------//
    //======================================== METODO PARA ELIMINAR UNA FICHA =========================================//
    //-----------------------------------------------------------------------------------------------------------------//
    public boolean Eliminarficha(int idficha) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM fichaestudiante WHERE idficha = ?");
            ps.setInt(1, idficha);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException e) {
            System.out.println("------------------------------------------------");
            System.out.println("Ha ocurrido un error al eliminar la ficha " + e);
            System.out.println("------------------------------------------------");
        }
        return false;

    }
    //================================================================================================================//
    
  
    
    
    //-----------------------------------------------------------------------------------------------------------------------//
    //==================================== METODO PARA ACTUALIZAR UN DATO EN LA FICHA =======================================//
    //-----------------------------------------------------------------------------------------------------------------------//
        public boolean editarficha(ficha objfi) {
    PreparedStatement ps;
    try {
        ps = conn.prepareStatement("call actualizarficha(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, objfi.getTipodeDocumento());
            ps.setString(2, objfi.getNúmerodocumentoidentificación());
            ps.setString(3, objfi.getPrimerapellidoestudiante());
            ps.setString(4, objfi.getSegundoapellidodelestudiante());
            ps.setString(5, objfi.getPrimernombredelestudiante());
            ps.setString(6, objfi.getSegundonombredelestudiante());
            ps.setString(7, objfi.getSexo());
            ps.setString(8, objfi.getGénerodelestudiante());
            ps.setString(9, objfi.getEstadocivil());
            ps.setString(10, objfi.getEtnia());
            ps.setString(11, objfi.getPuebloNacionales());
            ps.setString(12, objfi.getTipodesangre());
            ps.setString(13, objfi.getTienediscapacidad());
            ps.setString(14, objfi.getPorcentajedediscapacidad());
            ps.setString(15, objfi.getNroCarnetCONADIS());
            ps.setString(16, objfi.getTipodediscapacidad());
            ps.setString(17, objfi.getFechadenacimiento());
            ps.setString(18, objfi.getPaisnacionalidad());
            ps.setString(19, objfi.getCantóndenacimiento());
            ps.setString(20, objfi.getPaísderesidencia());
            ps.setString(21, objfi.getProvinciaderesidencia());
            ps.setString(22, objfi.getCantónderesidencia());
            ps.setString(23, objfi.getTipodeColegio());
            ps.setString(24, objfi.getModalidaddelaCarrera());
            ps.setString(25, objfi.getJornadadelaCarrera());
            ps.setString(26, objfi.getFechainicióestudiantelacarrera());
            ps.setString(27, objfi.getFechadematrícula());
            ps.setString(28, objfi.getTipodematrícula());
            ps.setString(29, objfi.getNivelAcadémico());
            ps.setString(30, objfi.getNúmerosemanasduraciónperíodoacadémico());
            ps.setString(31, objfi.getHarepetidounamateria());
            ps.setString(32, objfi.getParalelo());
            ps.setString(33, objfi.getHaperdidolagratuidad());
            ps.setString(34, objfi.getPoseepensióndiferenciada());
            ps.setString(35, objfi.getElestudianteseencuentradedicadoa());
            ps.setString(36, objfi.getElestudianteparaquéempleasusingresos());
            ps.setString(37, objfi.getLafamiliadelestudianterecibeelbonodedesarrollohumano());
            ps.setString(38, objfi.getElestudianteharealizadoprácticaspreprofesionales());
            ps.setString(39, objfi.getHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante());
            ps.setString(40, objfi.getTipodeinstituciónenelquerealizalasprácticaspreprofesionales());
            ps.setString(41, objfi.getSectoreconómicorealizólasprácticaspreprofesionale());
            ps.setString(42, objfi.getTipodebecaquerecibeelestudiante());
            ps.setString(43, objfi.getPrimerarazóndebeca());
            ps.setString(44, objfi.getSegundarazóndebeca());
            ps.setString(45, objfi.getTercerarazóndebeca());
            ps.setString(46, objfi.getCuartarazóndebeca());
            ps.setString(47, objfi.getQuintarazóndebeca());
            ps.setString(48, objfi.getSextarazóndebeca());
            ps.setDouble(49, objfi.getValordelmontodelabeca());
            ps.setString(50, objfi.getPorcentajebecaquecubreelvalordelarancel());
            ps.setString(51, objfi.getPorcentajedelabecaquecubrelamanutención());
            ps.setString(52, objfi.getTipodefinanciamientodelabeca());
            ps.setDouble(53, objfi.getValordelmontodelaayudaeconómica());
            ps.setString(54, objfi.getHaparticicipadoduranteperiodoproyectovinculaciónsocial());
            ps.setString(55, objfi.getAlcanceproyectovinculacionsociedad());
            ps.setString(56, objfi.getCorreoelectrónicodelestudiante());
            ps.setString(57, objfi.getNúmerodecelulardelestudiante());
            ps.setString(58, objfi.getNiveldeformacióndelpadre());
            ps.setString(59, objfi.getNiveformaciónmadre());
            ps.setDouble(60, objfi.getIngresosdelhogar());
            ps.setString(61, objfi.getNúmerodemiembrosdelhogar());
            ps.setInt(62, objfi.getIdficha());
            ps.execute();
            ps.close();
        return true;
    } catch (SQLException e) {
        System.out.println("------------------------------------------------");
        System.out.println("Ha ocurrido un error al editar la solicitud " + e);
        System.out.println("------------------------------------------------");
    }
    return false;
}
//--------------------------------------------------------------------------------------------------------------------//    


    

//---------------------------------------------------------------------------------------------------------//
    //======================= METODO PARA MOSTRAR LOS DATOS DE LA TABLA PARA EDITAR ===========================//
    //---------------------------------------------------------------------------------------------------------//
    public ficha buscarfich(int id) {
    ficha busqf = new ficha();
    String sSQL = "SELECT * FROM fichaestudiante WHERE idficha=?";
    try {
        ps = conn.prepareStatement(sSQL);
        ps.setInt(1, id);
        rs = ps.executeQuery();

        while (rs.next()) {
            busqf.setIdficha(rs.getInt("idficha"));
            busqf.setTipodeDocumento(rs.getString("TipodeDocumento"));
            busqf.setNúmerodocumentoidentificación(rs.getString("Númerodocumentoidentificación"));
            busqf.setPrimerapellidoestudiante(rs.getString("primerapellidoestudiante"));
            busqf.setSegundoapellidodelestudiante(rs.getString("Segundoapellidodelestudiante"));
            busqf.setPrimernombredelestudiante(rs.getString("Primernombredelestudiante"));
            busqf.setSegundonombredelestudiante(rs.getString("Segundonombredelestudiante"));
            busqf.setSexo(rs.getString("Sexo"));
            busqf.setGénerodelestudiante(rs.getString("Génerodelestudiante"));
            busqf.setEstadocivil(rs.getString("Estadocivil"));
            busqf.setEtnia(rs.getString("Etnia"));
            busqf.setPuebloNacionales(rs.getString("PuebloNacionales"));
            busqf.setTipodesangre(rs.getString("Tipodesangre"));
            busqf.setTienediscapacidad(rs.getString("Tienediscapacidad"));
            busqf.setPorcentajedediscapacidad(rs.getString("Porcentajedediscapacidad"));
            busqf.setNroCarnetCONADIS(rs.getString("NroCarnetCONADIS"));
            busqf.setTipodediscapacidad(rs.getString("Tipodediscapacidad"));
            busqf.setFechadenacimiento(rs.getString("Fechadenacimiento"));
            busqf.setPaisnacionalidad(rs.getString("Paisnacionalidad"));
            busqf.setCantóndenacimiento(rs.getString("Cantóndenacimiento"));
            busqf.setPaísderesidencia(rs.getString("Paísderesidencia"));
            busqf.setProvinciaderesidencia(rs.getString("Provinciaderesidencia"));
            busqf.setCantónderesidencia(rs.getString("Cantónderesidencia"));
            busqf.setTipodeColegio(rs.getString("TipodeColegio"));
            busqf.setModalidaddelaCarrera(rs.getString("ModalidaddelaCarrera"));
            busqf.setJornadadelaCarrera(rs.getString("JornadadelaCarrera"));
            busqf.setFechainicióestudiantelacarrera(rs.getString("Fechainicióestudiantelacarrera"));
            busqf.setFechadematrícula(rs.getString("Fechadematrícula"));
            busqf.setTipodematrícula(rs.getString("Tipodematrícula"));
            busqf.setNivelAcadémico(rs.getString("NivelAcadémico"));
            busqf.setNúmerosemanasduraciónperíodoacadémico(rs.getString("Númerosemanasduraciónperíodoacadémico"));
            busqf.setHarepetidounamateria(rs.getString("Harepetidounamateria"));
            busqf.setParalelo(rs.getString("Paralelo"));
            busqf.setHaperdidolagratuidad(rs.getString("Haperdidolagratuidad"));
            busqf.setPoseepensióndiferenciada(rs.getString("Poseepensióndiferenciada"));
            busqf.setElestudianteseencuentradedicadoa(rs.getString("Elestudianteseencuentradedicadoa"));
            busqf.setElestudianteparaquéempleasusingresos(rs.getString("Elestudianteparaquéempleasusingresos"));
            busqf.setLafamiliadelestudianterecibeelbonodedesarrollohumano(rs.getString("Lafamiliadelestudianterecibeelbonodedesarrollohumano"));
            busqf.setElestudianteharealizadoprácticaspreprofesionales(rs.getString("Elestudianteharealizadoprácticaspreprofesionales"));
            busqf.setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(rs.getString("Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante"));
            busqf.setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(rs.getString("Tipodeinstituciónenelquerealizalasprácticaspreprofesionales"));
            busqf.setSectoreconómicorealizólasprácticaspreprofesionale(rs.getString("Sectoreconómicorealizólasprácticaspreprofesionale"));
            busqf.setTipodebecaquerecibeelestudiante(rs.getString("Tipodebecaquerecibeelestudiante"));
            busqf.setPrimerarazóndebeca(rs.getString("Primerarazóndebeca"));
            busqf.setSegundarazóndebeca(rs.getString("Segundarazóndebeca"));
            busqf.setTercerarazóndebeca(rs.getString("Tercerarazóndebeca"));
            busqf.setCuartarazóndebeca(rs.getString("Cuartarazóndebeca"));
            busqf.setQuintarazóndebeca(rs.getString("Quintarazóndebeca"));
            busqf.setSextarazóndebeca(rs.getString("Sextarazóndebeca"));
            busqf.setValordelmontodelabeca(Double.parseDouble(rs.getString("Valordelmontodelabeca")));
            busqf.setPorcentajebecaquecubreelvalordelarancel(rs.getString("Porcentajebecaquecubreelvalordelarancel"));
            busqf.setPorcentajedelabecaquecubrelamanutención(rs.getString("Porcentajedelabecaquecubrelamanutención"));
            busqf.setTipodefinanciamientodelabeca(rs.getString("Tipodefinanciamientodelabeca"));
            busqf.setValordelmontodelaayudaeconómica(Double.parseDouble(rs.getString("Valordelmontodelaayudaeconómica")));
            busqf.setHaparticicipadoduranteperiodoproyectovinculaciónsocial(rs.getString("Haparticicipadoduranteperiodoproyectovinculaciónsocial"));
            busqf.setAlcanceproyectovinculacionsociedad(rs.getString("Alcanceproyectovinculacionsociedad"));
            busqf.setCorreoelectrónicodelestudiante(rs.getString("Correoelectrónicodelestudiante"));
            busqf.setNúmerodecelulardelestudiante(rs.getString("Númerodecelulardelestudiante"));
            busqf.setNiveldeformacióndelpadre(rs.getString("Niveldeformacióndelpadre"));
            busqf.setNiveformaciónmadre(rs.getString("Niveformaciónmadre"));
            busqf.setIngresosdelhogar(Double.parseDouble(rs.getString("Ingresosdelhogar")));
            busqf.setNúmerodemiembrosdelhogar(rs.getString("Númerodemiembrosdelhogar"));

            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en ficha.");
            System.out.println("------------------------------------------");
        }
    } catch (SQLException e) {
        System.out.println("------------------------------------------");
        System.out.println("Error al listar en ficha: " + e);
        System.out.println("------------------------------------------");
    }

    return busqf;
}

    //=============================================================================================================//
    
    
}

