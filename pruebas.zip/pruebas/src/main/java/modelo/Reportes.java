
package modelo;


public class Reportes {
 private int idficha;
 private String TipodeDocumento;
 private String Númerodocumentoidentificación;
 private String primerapellidoestudiante ;
 private String Segundoapellidodelestudiante;
 private String Primernombredelestudiante;
 private String Segundonombredelestudiante;
 private String Sexo;
 private String Génerodelestudiante;
 private String Estadocivil;
 private String Etnia;
 private String PuebloNacionales;
 private String Tipodesangre;
 private String Tienediscapacidad;
 private String Porcentajedediscapacidad;
 private String NroCarnetCONADIS;
 private String Tipodediscapacidad;
 private String Fechadenacimiento;
 private String Paisnacionalidad;
 private String Cantóndenacimiento;
 private String Paísderesidencia;
 private String Provinciaderesidencia;
 private String Cantónderesidencia;
 private String TipodeColegio;
 private String ModalidaddelaCarrera;
 private String JornadadelaCarrera;
 private String Fechainicióestudiantelacarrera;
 private String Fechadematrícula;
 private String Tipodematrícula;
 private String NivelAcadémico;
 private String Númerosemanasduraciónperíodoacadémico;
 private String Harepetidounamateria;
 private String Paralelo;
 private String Haperdidolagratuidad;
 private String Poseepensióndiferenciada;
 private String Elestudianteseencuentradedicadoa;
 private String Elestudianteparaquéempleasusingresos;
 private String Lafamiliadelestudianterecibeelbonodedesarrollohumano;     // SE AUMENTO
 private String Elestudianteharealizadoprácticaspreprofesionales;   
 private String Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante;
 private String Tipodeinstituciónenelquerealizalasprácticaspreprofesionales;
 private String Sectoreconómicorealizólasprácticaspreprofesionale;
 private String Tipodebecaquerecibeelestudiante;
 private String Primerarazóndebeca;
 private String Segundarazóndebeca;
 private String Tercerarazóndebeca;
 private String Cuartarazóndebeca;
 private String Quintarazóndebeca;
 private String Sextarazóndebeca;
 private double Valordelmontodelabeca;
 private String Porcentajebecaquecubreelvalordelarancel;
 private String Porcentajedelabecaquecubrelamanutención;
 private String Tipodefinanciamientodelabeca;
 private double Valordelmontodelaayudaeconómica;
 private String Haparticicipadoduranteperiodoproyectovinculaciónsocial;
 private String Alcanceproyectovinculacionsociedad;
 private String Correoelectrónicodelestudiante;
 private String Númerodecelulardelestudiante;
 private String Niveldeformacióndelpadre;
 private String Niveformaciónmadre;
 private double Ingresosdelhogar;
 private String Númerodemiembrosdelhogar;
 
 private int idbeca;
 private String tipo;
 private String certificadoestudiante;
 private String copiacedula;
 private String certifiadoIES;
 private String otrosdocumentos;
 private int fk_ficha;
 
 private int id;
 private String descripcion;
 private String observaciones;
 private int fk_solicitudes;

    public Reportes() {
    }

 
    public Reportes(int idficha, String TipodeDocumento, String Númerodocumentoidentificación, String primerapellidoestudiante, String Segundoapellidodelestudiante, String Primernombredelestudiante, String Segundonombredelestudiante, String Sexo, String Génerodelestudiante, String Estadocivil, String Etnia, String PuebloNacionales, String Tipodesangre, String Tienediscapacidad, String Porcentajedediscapacidad, String NroCarnetCONADIS, String Tipodediscapacidad, String Fechadenacimiento, String Paisnacionalidad, String Cantóndenacimiento, String Paísderesidencia, String Provinciaderesidencia, String Cantónderesidencia, String TipodeColegio, String ModalidaddelaCarrera, String JornadadelaCarrera, String Fechainicióestudiantelacarrera, String Fechadematrícula, String Tipodematrícula, String NivelAcadémico, String Númerosemanasduraciónperíodoacadémico, String Harepetidounamateria, String Paralelo, String Haperdidolagratuidad, String Poseepensióndiferenciada, String Elestudianteseencuentradedicadoa, String Elestudianteparaquéempleasusingresos, String Lafamiliadelestudianterecibeelbonodedesarrollohumano, String Elestudianteharealizadoprácticaspreprofesionales, String Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante, String Tipodeinstituciónenelquerealizalasprácticaspreprofesionales, String Sectoreconómicorealizólasprácticaspreprofesionale, String Tipodebecaquerecibeelestudiante, String Primerarazóndebeca, String Segundarazóndebeca, String Tercerarazóndebeca, String Cuartarazóndebeca, String Quintarazóndebeca, String Sextarazóndebeca, double Valordelmontodelabeca, String Porcentajebecaquecubreelvalordelarancel, String Porcentajedelabecaquecubrelamanutención, String Tipodefinanciamientodelabeca, double Valordelmontodelaayudaeconómica, String Haparticicipadoduranteperiodoproyectovinculaciónsocial, String Alcanceproyectovinculacionsociedad, String Correoelectrónicodelestudiante, String Númerodecelulardelestudiante, String Niveldeformacióndelpadre, String Niveformaciónmadre, double Ingresosdelhogar, String Númerodemiembrosdelhogar, int idbeca, String tipo, String certificadoestudiante, String copiacedula, String certifiadoIES, String otrosdocumentos, int fk_ficha, int id, String descripcion, String observaciones, int fk_solicitudes) {
        this.idficha = idficha;
        this.TipodeDocumento = TipodeDocumento;
        this.Númerodocumentoidentificación = Númerodocumentoidentificación;
        this.primerapellidoestudiante = primerapellidoestudiante;
        this.Segundoapellidodelestudiante = Segundoapellidodelestudiante;
        this.Primernombredelestudiante = Primernombredelestudiante;
        this.Segundonombredelestudiante = Segundonombredelestudiante;
        this.Sexo = Sexo;
        this.Génerodelestudiante = Génerodelestudiante;
        this.Estadocivil = Estadocivil;
        this.Etnia = Etnia;
        this.PuebloNacionales = PuebloNacionales;
        this.Tipodesangre = Tipodesangre;
        this.Tienediscapacidad = Tienediscapacidad;
        this.Porcentajedediscapacidad = Porcentajedediscapacidad;
        this.NroCarnetCONADIS = NroCarnetCONADIS;
        this.Tipodediscapacidad = Tipodediscapacidad;
        this.Fechadenacimiento = Fechadenacimiento;
        this.Paisnacionalidad = Paisnacionalidad;
        this.Cantóndenacimiento = Cantóndenacimiento;
        this.Paísderesidencia = Paísderesidencia;
        this.Provinciaderesidencia = Provinciaderesidencia;
        this.Cantónderesidencia = Cantónderesidencia;
        this.TipodeColegio = TipodeColegio;
        this.ModalidaddelaCarrera = ModalidaddelaCarrera;
        this.JornadadelaCarrera = JornadadelaCarrera;
        this.Fechainicióestudiantelacarrera = Fechainicióestudiantelacarrera;
        this.Fechadematrícula = Fechadematrícula;
        this.Tipodematrícula = Tipodematrícula;
        this.NivelAcadémico = NivelAcadémico;
        this.Númerosemanasduraciónperíodoacadémico = Númerosemanasduraciónperíodoacadémico;
        this.Harepetidounamateria = Harepetidounamateria;
        this.Paralelo = Paralelo;
        this.Haperdidolagratuidad = Haperdidolagratuidad;
        this.Poseepensióndiferenciada = Poseepensióndiferenciada;
        this.Elestudianteseencuentradedicadoa = Elestudianteseencuentradedicadoa;
        this.Elestudianteparaquéempleasusingresos = Elestudianteparaquéempleasusingresos;
        this.Lafamiliadelestudianterecibeelbonodedesarrollohumano = Lafamiliadelestudianterecibeelbonodedesarrollohumano;
        this.Elestudianteharealizadoprácticaspreprofesionales = Elestudianteharealizadoprácticaspreprofesionales;
        this.Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante = Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante;
        this.Tipodeinstituciónenelquerealizalasprácticaspreprofesionales = Tipodeinstituciónenelquerealizalasprácticaspreprofesionales;
        this.Sectoreconómicorealizólasprácticaspreprofesionale = Sectoreconómicorealizólasprácticaspreprofesionale;
        this.Tipodebecaquerecibeelestudiante = Tipodebecaquerecibeelestudiante;
        this.Primerarazóndebeca = Primerarazóndebeca;
        this.Segundarazóndebeca = Segundarazóndebeca;
        this.Tercerarazóndebeca = Tercerarazóndebeca;
        this.Cuartarazóndebeca = Cuartarazóndebeca;
        this.Quintarazóndebeca = Quintarazóndebeca;
        this.Sextarazóndebeca = Sextarazóndebeca;
        this.Valordelmontodelabeca = Valordelmontodelabeca;
        this.Porcentajebecaquecubreelvalordelarancel = Porcentajebecaquecubreelvalordelarancel;
        this.Porcentajedelabecaquecubrelamanutención = Porcentajedelabecaquecubrelamanutención;
        this.Tipodefinanciamientodelabeca = Tipodefinanciamientodelabeca;
        this.Valordelmontodelaayudaeconómica = Valordelmontodelaayudaeconómica;
        this.Haparticicipadoduranteperiodoproyectovinculaciónsocial = Haparticicipadoduranteperiodoproyectovinculaciónsocial;
        this.Alcanceproyectovinculacionsociedad = Alcanceproyectovinculacionsociedad;
        this.Correoelectrónicodelestudiante = Correoelectrónicodelestudiante;
        this.Númerodecelulardelestudiante = Númerodecelulardelestudiante;
        this.Niveldeformacióndelpadre = Niveldeformacióndelpadre;
        this.Niveformaciónmadre = Niveformaciónmadre;
        this.Ingresosdelhogar = Ingresosdelhogar;
        this.Númerodemiembrosdelhogar = Númerodemiembrosdelhogar;
        this.idbeca = idbeca;
        this.tipo = tipo;
        this.certificadoestudiante = certificadoestudiante;
        this.copiacedula = copiacedula;
        this.certifiadoIES = certifiadoIES;
        this.otrosdocumentos = otrosdocumentos;
        this.fk_ficha = fk_ficha;
        this.id = id;
        this.descripcion = descripcion;
        this.observaciones = observaciones;
        this.fk_solicitudes = fk_solicitudes;
    }

    public int getIdficha() {
        return idficha;
    }

    public String getTipodeDocumento() {
        return TipodeDocumento;
    }

    public String getNúmerodocumentoidentificación() {
        return Númerodocumentoidentificación;
    }

    public String getPrimerapellidoestudiante() {
        return primerapellidoestudiante;
    }

    public String getSegundoapellidodelestudiante() {
        return Segundoapellidodelestudiante;
    }

    public String getPrimernombredelestudiante() {
        return Primernombredelestudiante;
    }

    public String getSegundonombredelestudiante() {
        return Segundonombredelestudiante;
    }

    public String getSexo() {
        return Sexo;
    }

    public String getGénerodelestudiante() {
        return Génerodelestudiante;
    }

    public String getEstadocivil() {
        return Estadocivil;
    }

    public String getEtnia() {
        return Etnia;
    }

    public String getPuebloNacionales() {
        return PuebloNacionales;
    }

    public String getTipodesangre() {
        return Tipodesangre;
    }

    public String getTienediscapacidad() {
        return Tienediscapacidad;
    }

    public String getPorcentajedediscapacidad() {
        return Porcentajedediscapacidad;
    }

    public String getNroCarnetCONADIS() {
        return NroCarnetCONADIS;
    }

    public String getTipodediscapacidad() {
        return Tipodediscapacidad;
    }

    public String getFechadenacimiento() {
        return Fechadenacimiento;
    }

    public String getPaisnacionalidad() {
        return Paisnacionalidad;
    }

    public String getCantóndenacimiento() {
        return Cantóndenacimiento;
    }

    public String getPaísderesidencia() {
        return Paísderesidencia;
    }

    public String getProvinciaderesidencia() {
        return Provinciaderesidencia;
    }

    public String getCantónderesidencia() {
        return Cantónderesidencia;
    }

    public String getTipodeColegio() {
        return TipodeColegio;
    }

    public String getModalidaddelaCarrera() {
        return ModalidaddelaCarrera;
    }

    public String getJornadadelaCarrera() {
        return JornadadelaCarrera;
    }

    public String getFechainicióestudiantelacarrera() {
        return Fechainicióestudiantelacarrera;
    }

    public String getFechadematrícula() {
        return Fechadematrícula;
    }

    public String getTipodematrícula() {
        return Tipodematrícula;
    }

    public String getNivelAcadémico() {
        return NivelAcadémico;
    }

    public String getNúmerosemanasduraciónperíodoacadémico() {
        return Númerosemanasduraciónperíodoacadémico;
    }

    public String getHarepetidounamateria() {
        return Harepetidounamateria;
    }

    public String getParalelo() {
        return Paralelo;
    }

    public String getHaperdidolagratuidad() {
        return Haperdidolagratuidad;
    }

    public String getPoseepensióndiferenciada() {
        return Poseepensióndiferenciada;
    }

    public String getElestudianteseencuentradedicadoa() {
        return Elestudianteseencuentradedicadoa;
    }

    public String getElestudianteparaquéempleasusingresos() {
        return Elestudianteparaquéempleasusingresos;
    }

    public String getLafamiliadelestudianterecibeelbonodedesarrollohumano() {
        return Lafamiliadelestudianterecibeelbonodedesarrollohumano;
    }

    public String getElestudianteharealizadoprácticaspreprofesionales() {
        return Elestudianteharealizadoprácticaspreprofesionales;
    }

    public String getHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante() {
        return Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante;
    }

    public String getTipodeinstituciónenelquerealizalasprácticaspreprofesionales() {
        return Tipodeinstituciónenelquerealizalasprácticaspreprofesionales;
    }

    public String getSectoreconómicorealizólasprácticaspreprofesionale() {
        return Sectoreconómicorealizólasprácticaspreprofesionale;
    }

    public String getTipodebecaquerecibeelestudiante() {
        return Tipodebecaquerecibeelestudiante;
    }

    public String getPrimerarazóndebeca() {
        return Primerarazóndebeca;
    }

    public String getSegundarazóndebeca() {
        return Segundarazóndebeca;
    }

    public String getTercerarazóndebeca() {
        return Tercerarazóndebeca;
    }

    public String getCuartarazóndebeca() {
        return Cuartarazóndebeca;
    }

    public String getQuintarazóndebeca() {
        return Quintarazóndebeca;
    }

    public String getSextarazóndebeca() {
        return Sextarazóndebeca;
    }

    public double getValordelmontodelabeca() {
        return Valordelmontodelabeca;
    }

    public String getPorcentajebecaquecubreelvalordelarancel() {
        return Porcentajebecaquecubreelvalordelarancel;
    }

    public String getPorcentajedelabecaquecubrelamanutención() {
        return Porcentajedelabecaquecubrelamanutención;
    }

    public String getTipodefinanciamientodelabeca() {
        return Tipodefinanciamientodelabeca;
    }

    public double getValordelmontodelaayudaeconómica() {
        return Valordelmontodelaayudaeconómica;
    }

    public String getHaparticicipadoduranteperiodoproyectovinculaciónsocial() {
        return Haparticicipadoduranteperiodoproyectovinculaciónsocial;
    }

    public String getAlcanceproyectovinculacionsociedad() {
        return Alcanceproyectovinculacionsociedad;
    }

    public String getCorreoelectrónicodelestudiante() {
        return Correoelectrónicodelestudiante;
    }

    public String getNúmerodecelulardelestudiante() {
        return Númerodecelulardelestudiante;
    }

    public String getNiveldeformacióndelpadre() {
        return Niveldeformacióndelpadre;
    }

    public String getNiveformaciónmadre() {
        return Niveformaciónmadre;
    }

    public double getIngresosdelhogar() {
        return Ingresosdelhogar;
    }

    public String getNúmerodemiembrosdelhogar() {
        return Númerodemiembrosdelhogar;
    }

    public int getIdbeca() {
        return idbeca;
    }

    public String getTipo() {
        return tipo;
    }

    public String getCertificadoestudiante() {
        return certificadoestudiante;
    }

    public String getCopiacedula() {
        return copiacedula;
    }

    public String getCertifiadoIES() {
        return certifiadoIES;
    }

    public String getOtrosdocumentos() {
        return otrosdocumentos;
    }

    public int getFk_ficha() {
        return fk_ficha;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public int getFk_solicitudes() {
        return fk_solicitudes;
    }

    
    
    public void setIdficha(int idficha) {
        this.idficha = idficha;
    }

    public void setTipodeDocumento(String TipodeDocumento) {
        this.TipodeDocumento = TipodeDocumento;
    }

    public void setNúmerodocumentoidentificación(String Númerodocumentoidentificación) {
        this.Númerodocumentoidentificación = Númerodocumentoidentificación;
    }

    public void setPrimerapellidoestudiante(String primerapellidoestudiante) {
        this.primerapellidoestudiante = primerapellidoestudiante;
    }

    public void setSegundoapellidodelestudiante(String Segundoapellidodelestudiante) {
        this.Segundoapellidodelestudiante = Segundoapellidodelestudiante;
    }

    public void setPrimernombredelestudiante(String Primernombredelestudiante) {
        this.Primernombredelestudiante = Primernombredelestudiante;
    }

    public void setSegundonombredelestudiante(String Segundonombredelestudiante) {
        this.Segundonombredelestudiante = Segundonombredelestudiante;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public void setGénerodelestudiante(String Génerodelestudiante) {
        this.Génerodelestudiante = Génerodelestudiante;
    }

    public void setEstadocivil(String Estadocivil) {
        this.Estadocivil = Estadocivil;
    }

    public void setEtnia(String Etnia) {
        this.Etnia = Etnia;
    }

    public void setPuebloNacionales(String PuebloNacionales) {
        this.PuebloNacionales = PuebloNacionales;
    }

    public void setTipodesangre(String Tipodesangre) {
        this.Tipodesangre = Tipodesangre;
    }

    public void setTienediscapacidad(String Tienediscapacidad) {
        this.Tienediscapacidad = Tienediscapacidad;
    }

    public void setPorcentajedediscapacidad(String Porcentajedediscapacidad) {
        this.Porcentajedediscapacidad = Porcentajedediscapacidad;
    }

    public void setNroCarnetCONADIS(String NroCarnetCONADIS) {
        this.NroCarnetCONADIS = NroCarnetCONADIS;
    }

    public void setTipodediscapacidad(String Tipodediscapacidad) {
        this.Tipodediscapacidad = Tipodediscapacidad;
    }

    public void setFechadenacimiento(String Fechadenacimiento) {
        this.Fechadenacimiento = Fechadenacimiento;
    }

    public void setPaisnacionalidad(String Paisnacionalidad) {
        this.Paisnacionalidad = Paisnacionalidad;
    }

    public void setCantóndenacimiento(String Cantóndenacimiento) {
        this.Cantóndenacimiento = Cantóndenacimiento;
    }

    public void setPaísderesidencia(String Paísderesidencia) {
        this.Paísderesidencia = Paísderesidencia;
    }

    public void setProvinciaderesidencia(String Provinciaderesidencia) {
        this.Provinciaderesidencia = Provinciaderesidencia;
    }

    public void setCantónderesidencia(String Cantónderesidencia) {
        this.Cantónderesidencia = Cantónderesidencia;
    }

    public void setTipodeColegio(String TipodeColegio) {
        this.TipodeColegio = TipodeColegio;
    }

    public void setModalidaddelaCarrera(String ModalidaddelaCarrera) {
        this.ModalidaddelaCarrera = ModalidaddelaCarrera;
    }

    public void setJornadadelaCarrera(String JornadadelaCarrera) {
        this.JornadadelaCarrera = JornadadelaCarrera;
    }

    public void setFechainicióestudiantelacarrera(String Fechainicióestudiantelacarrera) {
        this.Fechainicióestudiantelacarrera = Fechainicióestudiantelacarrera;
    }

    public void setFechadematrícula(String Fechadematrícula) {
        this.Fechadematrícula = Fechadematrícula;
    }

    public void setTipodematrícula(String Tipodematrícula) {
        this.Tipodematrícula = Tipodematrícula;
    }

    public void setNivelAcadémico(String NivelAcadémico) {
        this.NivelAcadémico = NivelAcadémico;
    }

    public void setNúmerosemanasduraciónperíodoacadémico(String Númerosemanasduraciónperíodoacadémico) {
        this.Númerosemanasduraciónperíodoacadémico = Númerosemanasduraciónperíodoacadémico;
    }

    public void setHarepetidounamateria(String Harepetidounamateria) {
        this.Harepetidounamateria = Harepetidounamateria;
    }

    public void setParalelo(String Paralelo) {
        this.Paralelo = Paralelo;
    }

    public void setHaperdidolagratuidad(String Haperdidolagratuidad) {
        this.Haperdidolagratuidad = Haperdidolagratuidad;
    }

    public void setPoseepensióndiferenciada(String Poseepensióndiferenciada) {
        this.Poseepensióndiferenciada = Poseepensióndiferenciada;
    }

    public void setElestudianteseencuentradedicadoa(String Elestudianteseencuentradedicadoa) {
        this.Elestudianteseencuentradedicadoa = Elestudianteseencuentradedicadoa;
    }

    public void setElestudianteparaquéempleasusingresos(String Elestudianteparaquéempleasusingresos) {
        this.Elestudianteparaquéempleasusingresos = Elestudianteparaquéempleasusingresos;
    }

    public void setLafamiliadelestudianterecibeelbonodedesarrollohumano(String Lafamiliadelestudianterecibeelbonodedesarrollohumano) {
        this.Lafamiliadelestudianterecibeelbonodedesarrollohumano = Lafamiliadelestudianterecibeelbonodedesarrollohumano;
    }

    public void setElestudianteharealizadoprácticaspreprofesionales(String Elestudianteharealizadoprácticaspreprofesionales) {
        this.Elestudianteharealizadoprácticaspreprofesionales = Elestudianteharealizadoprácticaspreprofesionales;
    }

    public void setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(String Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante) {
        this.Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante = Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante;
    }

    public void setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(String Tipodeinstituciónenelquerealizalasprácticaspreprofesionales) {
        this.Tipodeinstituciónenelquerealizalasprácticaspreprofesionales = Tipodeinstituciónenelquerealizalasprácticaspreprofesionales;
    }

    public void setSectoreconómicorealizólasprácticaspreprofesionale(String Sectoreconómicorealizólasprácticaspreprofesionale) {
        this.Sectoreconómicorealizólasprácticaspreprofesionale = Sectoreconómicorealizólasprácticaspreprofesionale;
    }

    public void setTipodebecaquerecibeelestudiante(String Tipodebecaquerecibeelestudiante) {
        this.Tipodebecaquerecibeelestudiante = Tipodebecaquerecibeelestudiante;
    }

    public void setPrimerarazóndebeca(String Primerarazóndebeca) {
        this.Primerarazóndebeca = Primerarazóndebeca;
    }

    public void setSegundarazóndebeca(String Segundarazóndebeca) {
        this.Segundarazóndebeca = Segundarazóndebeca;
    }

    public void setTercerarazóndebeca(String Tercerarazóndebeca) {
        this.Tercerarazóndebeca = Tercerarazóndebeca;
    }

    public void setCuartarazóndebeca(String Cuartarazóndebeca) {
        this.Cuartarazóndebeca = Cuartarazóndebeca;
    }

    public void setQuintarazóndebeca(String Quintarazóndebeca) {
        this.Quintarazóndebeca = Quintarazóndebeca;
    }

    public void setSextarazóndebeca(String Sextarazóndebeca) {
        this.Sextarazóndebeca = Sextarazóndebeca;
    }

    public void setValordelmontodelabeca(double Valordelmontodelabeca) {
        this.Valordelmontodelabeca = Valordelmontodelabeca;
    }

    public void setPorcentajebecaquecubreelvalordelarancel(String Porcentajebecaquecubreelvalordelarancel) {
        this.Porcentajebecaquecubreelvalordelarancel = Porcentajebecaquecubreelvalordelarancel;
    }

    public void setPorcentajedelabecaquecubrelamanutención(String Porcentajedelabecaquecubrelamanutención) {
        this.Porcentajedelabecaquecubrelamanutención = Porcentajedelabecaquecubrelamanutención;
    }

    public void setTipodefinanciamientodelabeca(String Tipodefinanciamientodelabeca) {
        this.Tipodefinanciamientodelabeca = Tipodefinanciamientodelabeca;
    }

    public void setValordelmontodelaayudaeconómica(double Valordelmontodelaayudaeconómica) {
        this.Valordelmontodelaayudaeconómica = Valordelmontodelaayudaeconómica;
    }

    public void setHaparticicipadoduranteperiodoproyectovinculaciónsocial(String Haparticicipadoduranteperiodoproyectovinculaciónsocial) {
        this.Haparticicipadoduranteperiodoproyectovinculaciónsocial = Haparticicipadoduranteperiodoproyectovinculaciónsocial;
    }

    public void setAlcanceproyectovinculacionsociedad(String Alcanceproyectovinculacionsociedad) {
        this.Alcanceproyectovinculacionsociedad = Alcanceproyectovinculacionsociedad;
    }

    public void setCorreoelectrónicodelestudiante(String Correoelectrónicodelestudiante) {
        this.Correoelectrónicodelestudiante = Correoelectrónicodelestudiante;
    }

    public void setNúmerodecelulardelestudiante(String Númerodecelulardelestudiante) {
        this.Númerodecelulardelestudiante = Númerodecelulardelestudiante;
    }

    public void setNiveldeformacióndelpadre(String Niveldeformacióndelpadre) {
        this.Niveldeformacióndelpadre = Niveldeformacióndelpadre;
    }

    public void setNiveformaciónmadre(String Niveformaciónmadre) {
        this.Niveformaciónmadre = Niveformaciónmadre;
    }

    public void setIngresosdelhogar(double Ingresosdelhogar) {
        this.Ingresosdelhogar = Ingresosdelhogar;
    }

    public void setNúmerodemiembrosdelhogar(String Númerodemiembrosdelhogar) {
        this.Númerodemiembrosdelhogar = Númerodemiembrosdelhogar;
    }

    public void setIdbeca(int idbeca) {
        this.idbeca = idbeca;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setCertificadoestudiante(String certificadoestudiante) {
        this.certificadoestudiante = certificadoestudiante;
    }

    public void setCopiacedula(String copiacedula) {
        this.copiacedula = copiacedula;
    }

    public void setCertifiadoIES(String certifiadoIES) {
        this.certifiadoIES = certifiadoIES;
    }

    public void setOtrosdocumentos(String otrosdocumentos) {
        this.otrosdocumentos = otrosdocumentos;
    }

    public void setFk_ficha(int fk_ficha) {
        this.fk_ficha = fk_ficha;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setFk_solicitudes(int fk_solicitudes) {
        this.fk_solicitudes = fk_solicitudes;
    }


    
}
