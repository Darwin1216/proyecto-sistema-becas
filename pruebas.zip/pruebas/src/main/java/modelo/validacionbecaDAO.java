
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class validacionbecaDAO {
    private Conexion con;
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;

    public validacionbecaDAO(String jdbcURL, String jdbcUsername, String jdbcPassword) throws SQLException {
        con = new Conexion(jdbcURL, jdbcUsername, jdbcPassword);
        conn = con.connection();
        con.getjdbcConnection();
    }

    public boolean insertarvalidacion(validacionbecas objval) {
    boolean estado = false;
    PreparedStatement pstmt = null;
    String sql = "INSERT INTO validacion (descripcion, observaciones, fk_solicitudes) "
            + "VALUES (?, ?, ?)";
    try {
        con.connection();
        pstmt = con.getjdbcConnection().prepareStatement(sql);
        pstmt.setString(1, objval.getDescripcion());
        pstmt.setString(2, objval.getObservaciones());
        pstmt.setInt(3, objval.getFk_solicitudes());

        pstmt.executeUpdate();
        estado = true;
    } catch (SQLException objerr) {
        estado = false;
        objerr.printStackTrace();
    } finally {
        try {
            if (pstmt != null) {
                pstmt.close();
            }
            con.disconnect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return estado;
}
    
public List listar() {
    List<validacionbecas> listavalidacion = new ArrayList<>();
    String sSQL;
        sSQL = "SELECT * FROM validacion";
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
            validacionbecas val = new validacionbecas();
                val.setId(Integer.parseInt(rs.getString("idvalidacion")));
                val.setDescripcion(rs.getString("descripcion"));;
                val.setObservaciones(rs.getString("observaciones"));
                val.setFk_solicitudes(Integer.parseInt(rs.getString("fk_solicitudes")));
            listavalidacion.add(val);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Validaciones. Número de elementos en la lista: " + listavalidacion.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Validaciones: " + e);
            System.out.println("------------------------------------------");
        }
        return listavalidacion;
    }

public List listarvali() {
        ArrayList<validacionbecas> listavali = new ArrayList<>();
        String sSQL;
        sSQL = "SELECT * FROM viewvalidacion";
        try {
            ps = conn.prepareStatement(sSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                validacionbecas vista = new validacionbecas();
                vista.setId(Integer.parseInt(rs.getString("id")));
                vista.setNombre_ficha(rs.getString("nombre"));
                vista.setApellido_ficha(rs.getString("apellido"));
                vista.setCedulaficha_ficha(rs.getString("cedula"));
                vista.setTipo_solicitud(rs.getString("beca"));
                vista.setDescripcion(rs.getString("estado"));
                vista.setObservaciones(rs.getString("observaciones"));
                
                listavali.add(vista);
            }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Validaciones Listadas: ");
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar la validacion: " + e);
            System.out.println("------------------------------------------");
        }
        return listavali;
    }


    public List buscarvalidacion(int id) {
    List<validacionbecas> listavalidacionbusq = new ArrayList<>();
    String sSQL;
        sSQL = "SELECT * FROM viewvalidacion WHERE id="+id;
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
                validacionbecas valbusq = new validacionbecas();
                valbusq.setId(Integer.parseInt(rs.getString("id")));
                valbusq.setNombre_ficha(rs.getString("nombre"));
                valbusq.setApellido_ficha(rs.getString("apellido"));
                valbusq.setCedulaficha_ficha(rs.getString("cedula"));
                valbusq.setTipo_solicitud(rs.getString("beca"));
                valbusq.setDescripcion(rs.getString("estado"));
                valbusq.setObservaciones(rs.getString("observaciones"));
            listavalidacionbusq.add(valbusq);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Validaciones. Número de elementos en la lista: " + listavalidacionbusq.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Validaciones: " + e);
            System.out.println("------------------------------------------");
        }
        return listavalidacionbusq;
    }
    
    
    public boolean Eliminarvalidacion(int idval) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM validacion WHERE idvalidacion = ?");
            ps.setInt(1, idval);
            ps.execute();
            ps.close();
            return true;
        } catch (SQLException e) {
            System.out.println("------------------------------------------------");
            System.out.println("Ha ocurrido un error al eliminar la validacion " + e);
            System.out.println("------------------------------------------------");
        }
        return false;

    }
    
    
    
    
    
    //--------------------------------------------------------------------------------------------------------//
    //================================= METODO PARA ACTUALIZAR LAS VALIDACIONES ==================================//
    //--------------------------------------------------------------------------------------------------------//
    public boolean editarvalidaciones(validacionbecas idval) {
    PreparedStatement ps;
    try {
        ps = conn.prepareStatement("CALL actualizarvalidacion(?,?,?,?,?,?)");
        ps.setString(1, idval.getNombre_ficha());
        ps.setString(2, idval.getApellido_ficha());
        ps.setString(3, idval.getCedulaficha_ficha());
        ps.setString(4, idval.getDescripcion());
        ps.setString(5, idval.getObservaciones());
        ps.setInt(6, idval.getId());
        ps.execute();
        ps.close();
        return true;
    } catch (SQLException e) {
        System.out.println("------------------------------------------------");
        System.out.println("Ha ocurrido un error al editar la validacion " + e);
        System.out.println("------------------------------------------------");
    }
    return false;
}
    //----------------------------------------------------------------------------------------==============-//
    
    
    
    
    
    //---------------------------------------------------------------------------------------------------------//
    //======================= METODO PARA MOSTRAR LOS DATOS DE LA TABLA PARA EDITAR ===========================//
    //---------------------------------------------------------------------------------------------------------//
    public validacionbecas buscarvalidar(int id) {
        validacionbecas busq =new validacionbecas();
        String sSQL;
        sSQL = "SELECT * FROM viewvalidacion WHERE id="+id+";";
    try {
        ps = conn.prepareStatement(sSQL);
        rs = ps.executeQuery();
        while (rs.next()) {
                busq = new validacionbecas();
                busq.setId(Integer.parseInt(rs.getString("id")));
                busq.setNombre_ficha(rs.getString("nombre"));
                busq.setApellido_ficha(rs.getString("apellido"));
                busq.setCedulaficha_ficha(rs.getString("cedula"));
                busq.setTipo_solicitud(rs.getString("beca"));
                busq.setDescripcion(rs.getString("estado"));
                busq.setObservaciones(rs.getString("observaciones"));
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en validaciones.");
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en validaciones: " + e);
            System.out.println("------------------------------------------");
        }
        return busq;
    }
    //=============================================================================================================//
    
    
}
