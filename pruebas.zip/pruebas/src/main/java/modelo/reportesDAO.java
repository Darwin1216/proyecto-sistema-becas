
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class reportesDAO {
    
    private Conexion con;
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;

  

            
    public reportesDAO (String jdbcURL, String jdbcUsername, String jdbcPassword) throws SQLException {
        con = new Conexion(jdbcURL, jdbcUsername, jdbcPassword);
        conn = con.connection();
        con.getjdbcConnection();
    }
    
    public List listarreport() {
        List<Reportes> listareporte = new ArrayList<>();
        String sSQL;
        sSQL = "SELECT * FROM viewreportes ORDER BY idvalidacion";
        try {
            ps = conn.prepareStatement(sSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                Reportes rep = new  Reportes();
                //============================= DATOS DELA TABLA FICHA ===========================//
                rep.setIdficha(Integer.parseInt(rs.getString("idficha")));
                rep.setTipodeDocumento(rs.getString("TipodeDocumento"));
                rep.setNúmerodocumentoidentificación(rs.getString("Númerodocumentoidentificación"));
                rep.setPrimerapellidoestudiante(rs.getString("primerapellidoestudiante"));
                rep.setSegundoapellidodelestudiante(rs.getString("Segundoapellidodelestudiante"));
                rep.setPrimernombredelestudiante(rs.getString("Primernombredelestudiante"));
                rep.setSegundonombredelestudiante(rs.getString("Segundonombredelestudiante"));
                rep.setSexo(rs.getString("Sexo"));
                rep.setGénerodelestudiante(rs.getString("Génerodelestudiante"));
                rep.setEstadocivil(rs.getString("Estadocivil"));
                rep.setEtnia(rs.getString("Etnia"));
                rep.setPuebloNacionales(rs.getString("PuebloNacionales"));
                rep.setTipodesangre(rs.getString("Tipodesangre"));
                rep.setTienediscapacidad(rs.getString("Tienediscapacidad"));
                rep.setPorcentajedediscapacidad(rs.getString("Porcentajedediscapacidad"));
                rep.setNroCarnetCONADIS(rs.getString("NroCarnetCONADIS"));
                rep.setTipodediscapacidad(rs.getString("Tipodediscapacidad"));
                rep.setFechadenacimiento(rs.getString("Fechadenacimiento"));
                rep.setPaisnacionalidad(rs.getString("Paisnacionalidad"));
                rep.setCantóndenacimiento(rs.getString("Cantóndenacimiento"));
                rep.setPaísderesidencia(rs.getString("Paísderesidencia"));
                rep.setProvinciaderesidencia(rs.getString("Provinciaderesidencia"));
                rep.setCantónderesidencia(rs.getString("Cantónderesidencia"));
                rep.setTipodeColegio(rs.getString("TipodeColegio"));
                rep.setModalidaddelaCarrera(rs.getString("ModalidaddelaCarrera"));
                rep.setJornadadelaCarrera(rs.getString("JornadadelaCarrera"));
                rep.setFechainicióestudiantelacarrera(rs.getString("Fechainicióestudiantelacarrera"));
                rep.setFechadematrícula(rs.getString("Fechadematrícula"));
                rep.setTipodematrícula(rs.getString("Tipodematrícula"));
                rep.setNivelAcadémico(rs.getString("NivelAcadémico"));
                rep.setNúmerosemanasduraciónperíodoacadémico(rs.getString("Númerosemanasduraciónperíodoacadémico"));
                rep.setHarepetidounamateria(rs.getString("Harepetidounamateria"));
                rep.setParalelo(rs.getString("Paralelo"));
                rep.setHaperdidolagratuidad(rs.getString("Haperdidolagratuidad"));
                rep.setPoseepensióndiferenciada(rs.getString("Poseepensióndiferenciada"));
                rep.setElestudianteseencuentradedicadoa(rs.getString("Elestudianteseencuentradedicadoa"));
                rep.setElestudianteparaquéempleasusingresos(rs.getString("Elestudianteparaquéempleasusingresos"));
                rep.setLafamiliadelestudianterecibeelbonodedesarrollohumano(rs.getString("Lafamiliadelestudianterecibeelbonodedesarrollohumano"));
                rep.setElestudianteharealizadoprácticaspreprofesionales(rs.getString("Elestudianteharealizadoprácticaspreprofesionales"));
                rep.setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(rs.getString("Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante"));
                rep.setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(rs.getString("Tipodeinstituciónenelquerealizalasprácticaspreprofesionales"));
                rep.setSectoreconómicorealizólasprácticaspreprofesionale(rs.getString("Sectoreconómicorealizólasprácticaspreprofesionale"));
                rep.setTipodebecaquerecibeelestudiante(rs.getString("Tipodebecaquerecibeelestudiante"));
                rep.setPrimerarazóndebeca(rs.getString("Primerarazóndebeca"));
                rep.setSegundarazóndebeca(rs.getString("Segundarazóndebeca"));
                rep.setTercerarazóndebeca(rs.getString("Tercerarazóndebeca"));
                rep.setCuartarazóndebeca(rs.getString("Cuartarazóndebeca"));
                rep.setQuintarazóndebeca(rs.getString("Quintarazóndebeca"));
                rep.setSextarazóndebeca(rs.getString("Sextarazóndebeca"));
                rep.setValordelmontodelabeca(Double.parseDouble(rs.getString("Valordelmontodelabeca")));
                rep.setPorcentajebecaquecubreelvalordelarancel(rs.getString("Porcentajebecaquecubreelvalordelarancel"));
                rep.setPorcentajedelabecaquecubrelamanutención(rs.getString("Porcentajedelabecaquecubrelamanutención"));
                rep.setTipodefinanciamientodelabeca(rs.getString("Tipodefinanciamientodelabeca"));
                rep.setValordelmontodelaayudaeconómica(Double.parseDouble(rs.getString("Valordelmontodelaayudaeconómica")));
                rep.setHaparticicipadoduranteperiodoproyectovinculaciónsocial(rs.getString("Haparticicipadoduranteperiodoproyectovinculaciónsocial"));
                rep.setAlcanceproyectovinculacionsociedad(rs.getString("Alcanceproyectovinculacionsociedad"));
                rep.setCorreoelectrónicodelestudiante(rs.getString("Correoelectrónicodelestudiante"));
                rep.setNúmerodecelulardelestudiante(rs.getString("Númerodecelulardelestudiante"));
                rep.setNiveldeformacióndelpadre(rs.getString("Niveldeformacióndelpadre"));
                rep.setNiveformaciónmadre(rs.getString("Niveformaciónmadre"));
                rep.setIngresosdelhogar(Double.parseDouble(rs.getString("Ingresosdelhogar")));
                rep.setNúmerodemiembrosdelhogar(rs.getString("Númerodemiembrosdelhogar"));
                // ====================== Datos de la tabla solicitudes ============== //
                rep.setIdbeca(Integer.parseInt(rs.getString("idBeca")));
                rep.setTipo(rs.getString("tipo"));
                rep.setCertificadoestudiante(rs.getString("certificadoestudiante"));
                rep.setCopiacedula(rs.getString("Copiacedu"));
                rep.setCertifiadoIES(rs.getString("certificadoIES"));
                rep.setOtrosdocumentos(rs.getString("otrosdocumentos"));
                rep.setFk_ficha(Integer.parseInt(rs.getString("fk_ficha")));
                // ========================= DATOS DE LA TABLA VALIDACION ============================//
                rep.setId(Integer.parseInt(rs.getString("idvalidacion")));
                rep.setDescripcion(rs.getString("descripcion"));
                rep.setObservaciones(rs.getString("observaiones"));
                rep.setFk_solicitudes(Integer.parseInt(rs.getString("fk_solicitudes")));
                listareporte.add(rep);
            }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado los reportes. Número de elementos en la lista: " + listareporte.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar los reportes: " + e);
            System.out.println("------------------------------------------");
        }
        return listareporte;
    }
    
    
    
    
    public List buscar(int id) {
        List<Reportes> listabusqreportes = new ArrayList<>();
        String sSQL;
        sSQL = "SELECT * FROM viewreportes WHERE Númerodocumentoidentificación LIKE '%" + id + "%'";
        try {
            ps = conn.prepareStatement(sSQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                Reportes rep = new Reportes();
                rep.setIdficha(Integer.parseInt(rs.getString("idficha")));
                rep.setTipodeDocumento(rs.getString("TipodeDocumento"));
                rep.setNúmerodocumentoidentificación(rs.getString("Númerodocumentoidentificación"));
                rep.setPrimerapellidoestudiante(rs.getString("primerapellidoestudiante"));
                rep.setSegundoapellidodelestudiante(rs.getString("Segundoapellidodelestudiante"));
                rep.setPrimernombredelestudiante(rs.getString("Primernombredelestudiante"));
                rep.setSegundonombredelestudiante(rs.getString("Segundonombredelestudiante"));
                rep.setSexo(rs.getString("Sexo"));
                rep.setGénerodelestudiante(rs.getString("Génerodelestudiante"));
                rep.setEstadocivil(rs.getString("Estadocivil"));
                rep.setEtnia(rs.getString("Etnia"));
                rep.setPuebloNacionales(rs.getString("PuebloNacionales"));
                rep.setTipodesangre(rs.getString("Tipodesangre"));
                rep.setTienediscapacidad(rs.getString("Tienediscapacidad"));
                rep.setPorcentajedediscapacidad(rs.getString("Porcentajedediscapacidad"));
                rep.setNroCarnetCONADIS(rs.getString("NroCarnetCONADIS"));
                rep.setTipodediscapacidad(rs.getString("Tipodediscapacidad"));
                rep.setFechadenacimiento(rs.getString("Fechadenacimiento"));
                rep.setPaisnacionalidad(rs.getString("Paisnacionalidad"));
                rep.setCantóndenacimiento(rs.getString("Cantóndenacimiento"));
                rep.setPaísderesidencia(rs.getString("Paísderesidencia"));
                rep.setProvinciaderesidencia(rs.getString("Provinciaderesidencia"));
                rep.setCantónderesidencia(rs.getString("Cantónderesidencia"));
                rep.setTipodeColegio(rs.getString("TipodeColegio"));
                rep.setModalidaddelaCarrera(rs.getString("ModalidaddelaCarrera"));
                rep.setJornadadelaCarrera(rs.getString("JornadadelaCarrera"));
                rep.setFechainicióestudiantelacarrera(rs.getString("Fechainicióestudiantelacarrera"));
                rep.setFechadematrícula(rs.getString("Fechadematrícula"));
                rep.setTipodematrícula(rs.getString("Tipodematrícula"));
                rep.setNivelAcadémico(rs.getString("NivelAcadémico"));
                rep.setNúmerosemanasduraciónperíodoacadémico(rs.getString("Númerosemanasduraciónperíodoacadémico"));
                rep.setHarepetidounamateria(rs.getString("Harepetidounamateria"));
                rep.setParalelo(rs.getString("Paralelo"));
                rep.setHaperdidolagratuidad(rs.getString("Haperdidolagratuidad"));
                rep.setPoseepensióndiferenciada(rs.getString("Poseepensióndiferenciada"));
                rep.setElestudianteseencuentradedicadoa(rs.getString("Elestudianteseencuentradedicadoa"));
                rep.setElestudianteparaquéempleasusingresos(rs.getString("Elestudianteparaquéempleasusingresos"));
                rep.setLafamiliadelestudianterecibeelbonodedesarrollohumano(rs.getString("Lafamiliadelestudianterecibeelbonodedesarrollohumano"));
                rep.setElestudianteharealizadoprácticaspreprofesionales(rs.getString("Elestudianteharealizadoprácticaspreprofesionales"));
                rep.setHorasdelaúltimaprácticapreprofesionalquerealizóelestudiante(rs.getString("Horasdelaúltimaprácticapreprofesionalquerealizóelestudiante"));
                rep.setTipodeinstituciónenelquerealizalasprácticaspreprofesionales(rs.getString("Tipodeinstituciónenelquerealizalasprácticaspreprofesionales"));
                rep.setSectoreconómicorealizólasprácticaspreprofesionale(rs.getString("Sectoreconómicorealizólasprácticaspreprofesionale"));
                rep.setTipodebecaquerecibeelestudiante(rs.getString("Tipodebecaquerecibeelestudiante"));
                rep.setPrimerarazóndebeca(rs.getString("Primerarazóndebeca"));
                rep.setSegundarazóndebeca(rs.getString("Segundarazóndebeca"));
                rep.setTercerarazóndebeca(rs.getString("Tercerarazóndebeca"));
                rep.setCuartarazóndebeca(rs.getString("Cuartarazóndebeca"));
                rep.setQuintarazóndebeca(rs.getString("Quintarazóndebeca"));
                rep.setSextarazóndebeca(rs.getString("Sextarazóndebeca"));
                rep.setValordelmontodelabeca(Double.parseDouble(rs.getString("Valordelmontodelabeca")));
                rep.setPorcentajebecaquecubreelvalordelarancel(rs.getString("Porcentajebecaquecubreelvalordelarancel"));
                rep.setPorcentajedelabecaquecubrelamanutención(rs.getString("Porcentajedelabecaquecubrelamanutención"));
                rep.setTipodefinanciamientodelabeca(rs.getString("Tipodefinanciamientodelabeca"));
                rep.setValordelmontodelaayudaeconómica(Double.parseDouble(rs.getString("Valordelmontodelaayudaeconómica")));
                rep.setHaparticicipadoduranteperiodoproyectovinculaciónsocial(rs.getString("Haparticicipadoduranteperiodoproyectovinculaciónsocial"));
                rep.setAlcanceproyectovinculacionsociedad(rs.getString("Alcanceproyectovinculacionsociedad"));
                rep.setCorreoelectrónicodelestudiante(rs.getString("Correoelectrónicodelestudiante"));
                rep.setNúmerodecelulardelestudiante(rs.getString("Númerodecelulardelestudiante"));
                rep.setNiveldeformacióndelpadre(rs.getString("Niveldeformacióndelpadre"));
                rep.setNiveformaciónmadre(rs.getString("Niveformaciónmadre"));
                rep.setIngresosdelhogar(Double.parseDouble(rs.getString("Ingresosdelhogar")));
                rep.setNúmerodemiembrosdelhogar(rs.getString("Númerodemiembrosdelhogar"));
// ====================== Datos de la tabla solicitudes ============== //
                rep.setIdbeca(Integer.parseInt(rs.getString("idBeca")));
                rep.setTipo(rs.getString("tipo"));
                rep.setCertificadoestudiante(rs.getString("certificadoestudiante"));
                rep.setCopiacedula(rs.getString("Copiacedu"));
                rep.setCertifiadoIES(rs.getString("certificadoIES"));
                rep.setOtrosdocumentos(rs.getString("otrosdocumentos"));
                rep.setFk_ficha(Integer.parseInt(rs.getString("fk_ficha")));
// ========================= DATOS DE LA TABLA VALIDACION ============================//
                rep.setId(Integer.parseInt(rs.getString("idvalidacion")));
                rep.setDescripcion(rs.getString("descripcion"));
                rep.setObservaciones(rs.getString("observaiones"));
                rep.setFk_solicitudes(Integer.parseInt(rs.getString("fk_solicitudes")));

            listabusqreportes.add(rep);
        }
            System.out.println("------------------------------------------");
            System.out.println(sSQL);
            System.out.println("Se ha listado en Solicitudes. Número de elementos en la lista: " + listabusqreportes.size());
            System.out.println("------------------------------------------");
        } catch (SQLException e) {
            System.out.println("------------------------------------------");
            System.out.println("Error al listar en Solicitudes: " + e);
            System.out.println("------------------------------------------");
        }
        return listabusqreportes;
    }
    
    
    
    
}
