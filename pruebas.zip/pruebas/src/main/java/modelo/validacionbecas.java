
package modelo;


public class validacionbecas {
    private int id;
    private String descripcion;
    private String observaciones;
   private int fk_solicitudes;
    
    private String nombre_ficha;
    private String apellido_ficha;
    private String cedulaficha_ficha;
    private String tipo_solicitud;
 
    public validacionbecas(){
    
}
      public validacionbecas(int id,String descripcion, String observaciones, int fk_solicitudes) {
        this.id = id;
        this.descripcion=descripcion;
        this.observaciones = observaciones;
        this.fk_solicitudes = fk_solicitudes;
        
    }
      
      public validacionbecas(String descripcion, String observaciones, int fk_solicitudes) {
        this.descripcion=descripcion;
        this.observaciones = observaciones;
        this.fk_solicitudes = fk_solicitudes;
     }

    public validacionbecas(int id, String descripcion, String observaciones, String nombre_ficha, String apellido_ficha, String cedulaficha_ficha, String tipo_solicitud, int fk_solicitudes) {
        this.id = id;
        this.descripcion = descripcion;
        this.observaciones = observaciones;
        this.nombre_ficha = nombre_ficha;
        this.apellido_ficha = apellido_ficha;
        this.cedulaficha_ficha = cedulaficha_ficha;
        this.tipo_solicitud = tipo_solicitud;
        this.fk_solicitudes = fk_solicitudes;
    }

    public validacionbecas(String descripcion, String observaciones, String nombre_ficha, String apellido_ficha, String cedulaficha_ficha, String tipo_solicitud, int fk_solicitudes) {
        this.descripcion = descripcion;
        this.observaciones = observaciones;
        this.nombre_ficha = nombre_ficha;
        this.apellido_ficha = apellido_ficha;
        this.cedulaficha_ficha = cedulaficha_ficha;
        this.tipo_solicitud = tipo_solicitud;
        this.fk_solicitudes = fk_solicitudes;
    }

    public validacionbecas(int id, String descripcion, String observaciones, String nombre_ficha, String apellido_ficha, String cedulaficha_ficha, String tipo_solicitud) {
        this.id = id;
        this.descripcion = descripcion;
        this.observaciones = observaciones;
        this.nombre_ficha = nombre_ficha;
        this.apellido_ficha = apellido_ficha;
        this.cedulaficha_ficha = cedulaficha_ficha;
        this.tipo_solicitud = tipo_solicitud;
    }

    public validacionbecas(String descripcion, String observaciones, String nombre_ficha, String apellido_ficha, String cedulaficha_ficha, String tipo_solicitud) {
        this.descripcion = descripcion;
        this.observaciones = observaciones;
        this.nombre_ficha = nombre_ficha;
        this.apellido_ficha = apellido_ficha;
        this.cedulaficha_ficha = cedulaficha_ficha;
        this.tipo_solicitud = tipo_solicitud;
    }

    public validacionbecas(int id, String descripcion, String observaciones, String nombre_ficha, String apellido_ficha, String cedulaficha_ficha) {
        this.id = id;
        this.nombre_ficha = nombre_ficha;
        this.apellido_ficha = apellido_ficha;
        this.cedulaficha_ficha = cedulaficha_ficha;
        this.descripcion = descripcion;
        this.observaciones = observaciones;
    }
    

    public String getNombre_ficha() {
        return nombre_ficha;
    }

    public void setNombre_ficha(String nombre_ficha) {
        this.nombre_ficha = nombre_ficha;
    }

    public String getApellido_ficha() {
        return apellido_ficha;
    }

    public void setApellido_ficha(String apellido_ficha) {
        this.apellido_ficha = apellido_ficha;
    }

    public String getCedulaficha_ficha() {
        return cedulaficha_ficha;
    }

    public void setCedulaficha_ficha(String cedulaficha_ficha) {
        this.cedulaficha_ficha = cedulaficha_ficha;
    }

    public String getTipo_solicitud() {
        return tipo_solicitud;
    }

    public void setTipo_solicitud(String tipo_solicitud) {
        this.tipo_solicitud = tipo_solicitud;
    }
      
      

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getFk_solicitudes() {
        return fk_solicitudes;
    }

    public void setFk_solicitudes(int fk_solicitudes) {
        this.fk_solicitudes = fk_solicitudes;
    }
      
}
