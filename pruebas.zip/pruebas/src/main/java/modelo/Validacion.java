
package modelo;


public class Validacion {
    private  String usuario;
    private  String password;
   

    public Validacion(String usu, String pass) {
        usuario = usu;
        password = pass;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String ValidacionUsuario() {
        // Tenemos  la lógica de validación
        if (usuario.equalsIgnoreCase("admin") && password.equalsIgnoreCase("1234")) {
            return "Acceso Correcto";
        } else {
            return "Error de credenciales";
        }
    }
}
 
